﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AnalysisAndStaging
{
    public class GetSettlementInstructionsRspCepMsg
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetSettlementInstructionsRspCepMsg"/> class.
        /// </summary>
        public GetSettlementInstructionsRspCepMsg()
        {
            this.MessageName = "GetSettlementInstructionsRsp";
        }

        /// <summary>
        /// Gets or sets the Batch Id to which the message belongs.
        /// </summary>
        public int MessageBatchId { get; set; }

        /// <summary>
        /// The name of the message.
        /// this is the Cinnober message name, without the trailing "Msg"
        /// </summary>
        public string MessageName { get; set; }

        /// <summary>
        /// Gets or sets the criticality of the alert.
        /// <ul>Numbers indicate
        ///     <li>'1' Critical alert: stop processing.</li>
        ///     <li>'2' Warning alert: continue processing.</li>
        /// </ul>
        /// </summary>
        public int AlertSeverity { get; set; }

        /// <summary>
        /// Gets or sets the alert description
        /// </summary>
        public string AlertComment { get; set; }

        /// <summary>
        /// the primary key identifying the message.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets Id:[1] Status code. Code 3001 indicates that the request was 
        /// processed successfully. For other codes, see the Status Code list in the EMAPI 
        /// HTML description. 
        /// </summary>
        public int Code { get; set; }

        /// <summary>
        /// Gets or sets Id:[2] A textual description of the status code above. 
        /// </summary>
        public string Message { get; set; }

        /// <summary>
        /// Gets or sets Id:[3] Status code for each leg of the request. Only used for 
        /// batched requests. 
        /// </summary>
        public int?[] SubCode { get; set; }

        /// <summary>
        /// Gets or sets Id:[7] The bookmark marks a specific item in a list of data on the 
        /// server. The bookmark received in the response should be used in next request to 
        /// get next page of information. 
        /// </summary>
        public string Bookmark { get; set; }

        /// <summary>
        /// Gets or sets Id:[6] Settlement instructions. 
        /// </summary>
        public SettlementInstructionCepMsg[] Instructions { get; set; }
    }
}
