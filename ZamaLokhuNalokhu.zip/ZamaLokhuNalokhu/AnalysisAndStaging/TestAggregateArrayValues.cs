using System;
using System.Linq;
using AutoFixture.Xunit2;
using Xunit;
using FluentAssertions;
using Xunit.Abstractions;

namespace AnalysisAndStaging
{
    public class TestAggregateArrayValues
    {
        private readonly ITestOutputHelper _testOutputHelper;

        public TestAggregateArrayValues(ITestOutputHelper testOutputHelper)
        {
            _testOutputHelper = testOutputHelper;
        }

        [Theory]
        [AutoData]
        public void TestSumAmount(GetSettlementInstructionsRspCepMsg settlementInstructions)
        {
            var expected = new decimal(0);
            foreach (var instruction in settlementInstructions.Instructions)
            {
                expected += (decimal) instruction.Amount;
                _testOutputHelper.WriteLine("Current: {0}", instruction.Amount);
            }

            var actual = this.GetTotalAmount(settlementInstructions);
            _testOutputHelper.WriteLine("Expected: {0} | Actual: {1}", expected, actual);

            actual.Should().Be(expected, "same logic");
        }

        decimal GetTotalAmount(GetSettlementInstructionsRspCepMsg settlementInstructions)
        {
            return settlementInstructions.Instructions.Sum(instruction => (decimal) instruction.Amount);
        }
    }
}
