﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AnalysisAndStaging
{
	public partial class SettlementInstructionCepMsg
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="SettlementInstructionCepMsg"/> class.
		/// </summary>
		public SettlementInstructionCepMsg()
		{
			this.MessageName = "SettlementInstruction";
		}

		/// <summary>
		/// Gets or sets the Batch Id to which the message belongs.
		/// </summary>
		public int MessageBatchId { get; set; }

		/// <summary>
		/// The name of the message.
		/// this is the Cinnober message name, without the trailing "Msg"
		/// </summary>
		public string MessageName { get; set; }

		/// <summary>
		/// Gets or sets the criticality of the alert.
		/// <ul>Numbers indicate
		///     <li>'1' Critical alert: stop processing.</li>
		///     <li>'2' Warning alert: continue processing.</li>
		/// </ul>
		/// </summary>
        public int AlertSeverity { get; set; }

		/// <summary>
		/// Gets or sets the alert description
		/// </summary>
		public string AlertComment { get; set; }

		/// <summary>
		/// the primary key identifying the message.
		/// </summary>
		public int Id { get; set; }

		/// <summary>
		/// Gets or sets Id:[1] System generated unique ID. 
		/// </summary>
		public long? InstructionId { get; set; }

		/// <summary>
		/// Gets or sets Id:[2] Settlement date. The format is yyyy-MM-dd. 
		/// </summary>
		public string SettlementDate { get; set; }

		/// <summary>
		/// Gets or sets Id:[3] Message reference no. The reference is built out of 3 
		/// components 1. 76 (CM receives payment from JSE) or 77 (CM payments, JSE 
		/// receives) 2. CM template (from member) 3. Settlement date E.g. 760210515, Merril 
		/// Lynch receives payment on May 21, 2015 
		/// </summary>
		public string ReferenceNo { get; set; }

		/// <summary>
		/// Gets or sets Id:[4] JSE BIC. 
		/// </summary>
		public string SendCode { get; set; }

		/// <summary>
		/// Gets or sets Id:[10] The sending member account where the position effect should 
		/// be booked due to this instruction. 
		/// </summary>
		public string PlusAccount { get; set; }

		/// <summary>
		/// Gets or sets Id:[6] BIC code of the settlement bank of the paying member. Note 
		/// that this can be the BIC of the settlement bank of JSE. 
		/// </summary>
		public string SenderBIC { get; set; }

		/// <summary>
		/// Gets or sets Id:[7] Branch no of the sender (used for SWIFT). 
		/// </summary>
		public string SenderBranch { get; set; }

		/// <summary>
		/// Gets or sets Id:[8] Account number that the receiving member has in the 
		/// settlement bank. Note that this can be the account of the clearing house. 
		/// </summary>
		public string SenderAccountId { get; set; }

		/// <summary>
		/// Gets or sets Id:[9] The external account from which the amount should be moved. 
		/// </summary>
		public string ExternalFromAccount { get; set; }

		/// <summary>
		/// Gets or sets Id:[5] The receiving member account where the position effect 
		/// should be booked due to this instruction. 
		/// </summary>
		public string MinusAccount { get; set; }

		/// <summary>
		/// Gets or sets Id:[11] BIC code of the settlement bank of the receiving member. 
		/// Note that this can be the BIC of the settlement bank of JSE. 
		/// </summary>
		public string ReceiverBIC { get; set; }

		/// <summary>
		/// Gets or sets Id:[12] Branch no of the receiver (used for swift). 
		/// </summary>
		public string ReceiverBranch { get; set; }

		/// <summary>
		/// Gets or sets Id:[13] Account number that the receiving member has in the 
		/// settlement bank. Note that this can be the account of the clearing house. 
		/// </summary>
		public string ReceiverAccountId { get; set; }

		/// <summary>
		/// Gets or sets Id:[14] The external account to which the amount should be moved. 
		/// </summary>
		public string ExternalToAccount { get; set; }

		/// <summary>
		/// Gets or sets Id:[15] The amount to move. 
		/// </summary>
		public decimal? Amount { get; set; }

		/// <summary>
		/// Gets or sets Id:[16] The sum of reported settled amounts that are waiting for 
		/// confirmation on a position update. 
		/// </summary>
		public decimal? UnconfirmedSettledAmount { get; set; }

		/// <summary>
		/// Gets or sets Id:[17] The sum of reported settled amounts that have been matched 
		/// to this instruction. 
		/// </summary>
		public decimal? SettledAmount { get; set; }

		/// <summary>
		/// Gets or sets Id:[18] Currency in which the amount is settled. The currency code 
		/// according to ISO 4217. 
		/// </summary>
		public string CurrencyId { get; set; }

		/// <summary>
		/// Gets or sets Id:[19] Instruction state. 
		/// </summary>
		public string SettlementInstructionState { get; set; }

		/// <summary>
		/// Gets or sets Id:[20] Refers to the parent settlement run. 
		/// </summary>
		public long? SettlementRunId { get; set; }
	}
}
