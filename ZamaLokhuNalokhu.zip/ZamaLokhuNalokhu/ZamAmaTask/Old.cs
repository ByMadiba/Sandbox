﻿//using System;
//using System.Collections.Generic;
//using System.Diagnostics;
//using System.IO;
//using System.Linq;
//using System.Runtime.InteropServices.WindowsRuntime;
//using System.Threading;
//using System.Threading.Tasks;

//namespace ZamAmaTask
//{
//    class CustomData
//    {
//        public TimeSpan CreationTime;
//        public int Name;
//        public int ThreadNum;
//    }

//    /// <summary>
//    /// Synchronous Programming
//    /// Tasks are run sequentially
//    /// Asynchronous Programming
//    /// Tasks are run in Parallel
//    /// </summary>
//    class Program
//    {
//        /*
//         * The Task Parallel Library (TPL) is a set of public types and APIs in the System.Threading and System.Threading.Tasks namespaces.
//         * The purpose of the TPL is to make developers more productive by simplifying the process of adding parallelism and concurrency to applications.
//         * The TPL scales the degree of concurrency dynamically to most efficiently use all the processors that are available.
//         * In addition, the TPL handles the partitioning of the work, the scheduling of threads on the ThreadPool, cancellation support, state management, and other low-level details.
//         * By using TPL, you can maximize the performance of your code while focusing on the work that your program is designed to accomplish.
//         */

//        private static int maxLoops = 7;

//        static void Main(string[] args)
//        {
//            Console.WriteLine("Hello World! Ngidlala ngama task");

//            //ReadLinesInFile();

//            // ReadLinesInFileAsync();

//            ExecuteMyAsync();

//            Func<Task<int>> getDataFromNetworkLambda = async () =>
//            {
//                // simulate a network call
//                await Task.Delay(
//                    150); // NB! Will not block the CPU // .Delay won't block the thread, but will free the thread // hey C# if you have anything else to do, go ahead and do it

//                // once above task is finished, continue with below
//                var result = 47;

//                return result;
//            };


//            //var line = Console.ReadLine();

//            //Console.WriteLine("You wrote {0}", line);

//            // ASYNC do not block calling thread

//            // redirect standard output & input

//            //TaskFactoryStartNew();
//            //DetachedChildTasks();
//            //// async modifier specifies that method is async

//            //// await operator suspends evaluation of the enclosing async method until the async operation completes

//            //var syncRun = ExecuteSync();

//            //var parallel = ExecuteParallel();

//            //var asyncTask = ExecuteAsync();
//        }

//        static async Task<int> GetDataFromNetworkAsync()
//        {
//            // simulate a network call
//            await Task.Delay(150); // NB! Will not block the CPU // .Delay won't block the thread, but will free the thread // hey C# if you have anything else to do, go ahead and do it

//            // once above task is finished, continue with below
//            var result = 47;

//            return result;
//        }

//        static async void ExecuteMyAsync()
//        {
//            var myInt = await GetDataFromNetworkAsync();
//        }

//        static async Task ReadFileAsync()
//        {
//            var lines = await File.ReadAllLinesAsync("TheHallsOfAmenti.txt");

//            var output = new List<string>();

//            foreach (var line in lines)
//            {
//                Console.WriteLine(line);
//            }
//        }

//        static void ReadLinesInFile()
//        {
//            var lines = File.ReadAllLines("TheHallsOfAmenti.txt");
//            foreach (var line in lines)
//            {
//                Console.WriteLine(line);
//            }
//        }
//        static void ReadLinesInFileAsync()
//        {
//            var fileReadTask = File.ReadAllLinesAsync("TheHallsOfAmenti.txt");
//            /*
//            Console.WriteLine(fileReadTask.Status); // WaitingForActivation
//            Thread.Sleep(1);
//            Console.WriteLine(fileReadTask.Status); // RanToCompletion Amazing! Just one ms
//            */
//            File.ReadAllLinesAsync("TheHallsOfAmenti.txt")
//                .ContinueWith(t =>
//                {
//                    // Task will be completed!
//                    // ContinueWith is scheduling the next part
//                    // access the task result

//                    foreach (var line in t.Result)
//                    {
//                        Console.WriteLine(line);
//                    }
//                });
//            Console.WriteLine("We are here now");
//            Console.ReadLine();
//            /* ABOVE: ReadAllLines is not complete yet. i.e. Schedules it BUT it immediately continues*/
//        }

//        static void ReadLinesInFileFaultedAsync()
//        {
//            var fileReadTask = File.ReadAllLinesAsync("TheHallsOfAmentiii.txt");
//            /*
//            Console.WriteLine(fileReadTask.Status); // WaitingForActivation
//            Thread.Sleep(1);
//            Console.WriteLine(fileReadTask.Status); // RanToCompletion Amazing! Just one ms
//            */
//            File.ReadAllLinesAsync("TheHallsOfAmentiiii.txt")
//                .ContinueWith(t =>
//                {
//                    // Task will be completed!
//                    // ContinueWith is scheduling the next part
//                    // access the task result

//                    if (t.IsFaulted)
//                    {
//                        Console.WriteLine(t.Exception);
//                        return;
//                    }

//                    foreach (var line in t.Result)
//                    {
//                        Console.WriteLine(line);
//                    }
//                });
//            Console.WriteLine("We are here now");
//            Console.ReadLine();
//            /* ABOVE: ReadAllLines is not complete yet. i.e. Schedules it BUT it immediately continues*/
//        }

//        static void TaskFactoryStartNew()
//        {
//            Console.WriteLine("Processing Task.Factory.StartNew (With WaitAll)...");
//            Console.WriteLine(
//                "Create the task object by using an Action(Of Object) to pass in custom data to the Task constructor. This is useful when you need to capture outer variables from within a loop.");

//            Console.WriteLine(
//                "This state is passed as an argument to the task delegate, and it can be accessed from the task object by using the Task.AsyncState property. The following example is a variation on the previous example. It uses the AsyncState property to display information about the CustomData objects passed to the lambda expression.");

//            Task[] taskArray = new Task[10];
//            for (int i = 0; i < taskArray.Length; i++)
//            {
//                taskArray[i] = Task.Factory.StartNew((Object obj) =>
//                {
//                    if (!(obj is CustomData data))
//                        return;

//                    data.ThreadNum = Thread.CurrentThread.ManagedThreadId;
//                },
//                    new CustomData() { Name = i, CreationTime = DateTime.Now.TimeOfDay });
//            }
//            Task.WaitAll(taskArray);
//            foreach (var task in taskArray)
//            {
//                if (task.AsyncState is CustomData data)
//                    Console.WriteLine("Task #{0} created at {1}, ran on thread #{2}.",
//                        data.Name, data.CreationTime, data.ThreadNum);
//            }
//        }

//        static void DetachedChildTasks()
//        {
//            var outer = Task.Factory.StartNew(() =>
//            {
//                Console.WriteLine("Outer task beginning.");

//                var child = Task.Factory.StartNew(() =>
//                {
//                    Thread.SpinWait(5000);
//                    Console.WriteLine("Detached task completed.");
//                });
//            });

//            outer.Wait();
//            Console.WriteLine("Outer task completed.");
//        }

//        static bool ExecuteSync()
//        {
//            Console.WriteLine("Processing sync jobs...");
//            var sw = Stopwatch.StartNew();
//            ExecuteFirstJob();
//            ExecuteSecondJob();
//            Console.WriteLine("Sync ran in {0}ms", sw.ElapsedMilliseconds);

//            return true;
//        }

//        static bool ExecuteParallel()
//        {
//            Console.WriteLine("Processing Parallel jobs...");
//            Console.WriteLine("True Parallel is for multiple CPU's. Asynchronous programming is on multiple threads");
//            var sw = Stopwatch.StartNew();
//            Parallel.Invoke(() => ExecuteFirstJob(), () => ExecuteSecondJob());
//            Console.WriteLine("Parallel.Invoke ran in {0}ms", sw.ElapsedMilliseconds);

//            return true;
//        }

//        static async Task<bool> ExecuteAsync()
//        {
//            Console.WriteLine("Processing async jobs...");

//            // await task is sync until sync is finished
//            // we are not blocking main thread
//            // done in background
//            //var first = await ExecuteFirstJobAsync(); 
//            //var second = await ExecuteSecondJobAsync();

//            var sw = Stopwatch.StartNew();
//            var tasks = new List<Task> { ExecuteFirstJobAsync(), ExecuteSecondJobAsync() }; //, Task.Delay(1000)};

//            await Task.WhenAll(tasks);
//            Console.WriteLine("Async ran in {0}ms", sw.ElapsedMilliseconds);

//            return true;
//        }

//        static string ExecuteFirstJob()
//        {
//            for (int i = 0; i < maxLoops; i++)
//            {
//                Console.WriteLine("Processing 1st job ...{0}", i);
//            }

//            return "1st job complete";
//        }

//        static async Task<string> ExecuteFirstJobAsync()
//        {
//            return await Task.FromResult(ExecuteFirstJob());
//            for (int i = 0; i < maxLoops; i++)
//            {
//                Console.WriteLine("Processing 1st job async ...{0}", i);
//            }

//            return "1st job complete";
//        }

//        static string ExecuteSecondJob()
//        {
//            for (int i = 0; i < maxLoops; i++)
//            {
//                Console.WriteLine("Processing 2nd job...{0}", i);
//            }

//            return "2nd job complete";
//        }

//        static async Task<string> ExecuteSecondJobAsync()
//        {
//            //Task.Delay(1000);
//            return await Task.FromResult(ExecuteSecondJob());
//            for (int i = 0; i < maxLoops; i++)
//            {
//                Console.WriteLine("Processing 2nd job async...{0}", i);
//            }

//            return "2nd job complete";
//        }

//        static string ExecuteThirdJob()
//        {
//            for (int i = 0; i < maxLoops; i++)
//            {
//                Console.WriteLine("Processing 3rd job. Depends on 2nd job...{0}", i);
//            }

//            return "3rd job complete";
//        }
//    }
//}
