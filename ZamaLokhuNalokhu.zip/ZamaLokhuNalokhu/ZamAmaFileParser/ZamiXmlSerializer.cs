﻿using System.IO;
using System.Xml.Serialization;
using FluentAssertions;
using Xunit;

namespace ZamAmaFileParser
{
    public class ZamiXmlSerializer
    {
        [Fact]
        public void TestWriteObjectToXml()
        {
            WriteXml().Should().BeTrue("testing xml object serialization");
        }

        bool WriteXml()
        {
            Person persona = new Person();

            XmlSerializer xs = new XmlSerializer(typeof(Person));

            TextWriter txtWriter = new StreamWriter(@"C:\Users\BongekaM\source\repos\ZamaLokhuNalokhu\ZamAmaFileParser\Examples\ObjectSerialization.xml");

            xs.Serialize(txtWriter, persona);

            txtWriter.Close();

            return true;
        }
    }

    /// <summary>
    /// must be public for XmlSerializer
    /// </summary>
    public class Person
    {
        public int ID = 123456789;
        public string Name = "Jacob Zuma";
        public string Subject = "Intelligence";
    }
}
