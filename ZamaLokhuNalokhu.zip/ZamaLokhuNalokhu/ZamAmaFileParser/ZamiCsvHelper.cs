using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using CsvHelper;
using CsvHelper.Configuration;
using Newtonsoft.Json.Linq;
using Xunit;
using FluentAssertions;

namespace ZamAmaFileParser
{
    public class ZamiCsvHelper
    {
        [Fact]
        public void ShouldParseCsvFile()
        {
            var sut = this.LoadCsvFile(@"C:\Users\BongekaM\source\repos\ZamaLokhuNalokhu\ZamAmaFileParser\Examples\example.csv");
            sut.Should().NotBeNullOrEmpty("Parse correctly");
            sut.Should().NotBeNull("parsed correctly");

            sut.Should().NotBeNullOrEmpty("Parse correctly");
            sut.Any().Should().BeTrue("Parse correctly");

            foreach (var systemUnderTest in sut)
            {
                var jObject = JObject.FromObject(systemUnderTest);

                var properties = jObject.Properties();

                properties.Any().Should().BeTrue("parsed correctly with headers");
                properties.Count().Should().BeGreaterThan(1, "each comma should be a separate header");

                foreach (var jProperty in properties)
                {
                    var jName = jProperty.Name;
                    jName.Should().NotBeNullOrEmpty("must have header");
                    var jValue = Convert.ToString(jProperty.Value);
                    jValue.Should().NotBeNull("parsed value correctly");
                }
            }
        }
        
        [Fact]
        public void ShouldParseCsvFile_WithBadDataExceptionIgnored()
        {
            var filePath =
                @"C:\Users\BongekaM\source\repos\ZamaLokhuNalokhu\ZamAmaFileParser\Examples\MoreComplexExample.csv";
            var sut = this.LoadCsvFile(filePath, true);
            sut.Should().NotBeNullOrEmpty("Parse correctly");
            sut.Should().NotBeNull("parsed correctly");

            sut.Should().NotBeNullOrEmpty("Parse correctly");
            sut.Any().Should().BeTrue("Parse correctly");

            var rawLines = File.ReadAllLines(filePath);
            var rawCount = rawLines.Length;
            var sutCount = sut.Count;

            sutCount.Should().Be(rawCount - 1, "same file parsed minues one for header"); // minus 1 for header

            foreach (var systemUnderTest in sut)
            {
                var jObject = JObject.FromObject(systemUnderTest);

                var properties = jObject.Properties();

                properties.Any().Should().BeTrue("parsed correctly with headers");
                properties.Count().Should().BeGreaterThan(1, "each comma should be a separate header");

                foreach (var jProperty in properties)
                {
                    var jName = jProperty.Name;
                    jName.Should().NotBeNullOrEmpty("must have header");
                    var jValue = Convert.ToString(jProperty.Value);
                    jValue.Should().NotBeNull("parsed value correctly");
                }
            }
        }

        JArray LoadCsvFile(string path)
        {
            using (var reader = new StreamReader(path))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                var records = csv.GetRecords<dynamic>();
                var jArray = JArray.FromObject(records);

                return jArray;
            }
        }

        JArray LoadCsvFile(string path, bool ignoreBadData)
        {
            using (var reader = new StreamReader(path))
            {
                List<string> badRecord = new List<string>();

                var config = new CsvConfiguration(CultureInfo.InvariantCulture)
                {
                    Delimiter = ",",
                    Mode = CsvMode.NoEscape,
                    BadDataFound = context => badRecord.Add(context.RawRecord)
                };

                using (var csv = new CsvReader(reader, config))
                {
                    var records = csv.GetRecords<dynamic>();

                    var jArray = JArray.FromObject(records);

                    return jArray;
                }
            }
        }
    }
}
