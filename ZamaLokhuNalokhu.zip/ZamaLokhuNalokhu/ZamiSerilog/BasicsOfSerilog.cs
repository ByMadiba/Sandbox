using System;
using Xunit;

namespace ZamiSerilog
{
    public class BasicsOfSerilog
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
