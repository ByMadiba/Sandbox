﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommandLine;

namespace ZamaICommandLineParser
{
    internal class OptionsWithActions
    {
        internal Task<int> RunAndReturnExitCode(ParserResult<Options> opts)
        {
            Console.WriteLine(opts.Value);
            Console.WriteLine(opts.Tag);
            Console.WriteLine(opts.TypeInfo.Current);
            return Task.FromResult(777);
        }

        internal Task<int> RunAndReturnExitCode(Options opts)
        {
            Console.WriteLine(opts.Offset);
            Console.WriteLine(opts.Verbose);
            Console.WriteLine(opts.InputFiles);

            foreach (var optsInputFile in opts.InputFiles)
            {
                Console.WriteLine("File: {0}", optsInputFile);
            }

            return Task.FromResult(777);
        }

        internal int RunAndReturnNumber(Options opts)
        {
            Console.WriteLine(opts.InputFiles);
            return 777;
        }
        internal int RunAddAndReturnExitCode(AddOptions opts)
        {
            Console.WriteLine(opts.FileName);
            return 777;
        }

        internal int RunCommitAndReturnExitCode(CommitOptions opts)
        {
            Console.WriteLine(opts.FileName);
            return 888;
        }

        internal int RunCloneAndReturnExitCode(CloneOptions opts)
        {
            Console.WriteLine(opts.FileName);
            return 999;
        }
    }
}
