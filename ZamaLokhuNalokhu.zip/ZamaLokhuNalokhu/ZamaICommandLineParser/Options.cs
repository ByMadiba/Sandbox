﻿using System.Collections.Generic;
using CommandLine;

namespace ZamaICommandLineParser
{
    public class BasicsOptions
    {
        [Option('v', "verbose", Required = false, HelpText = "Set output to verbose messages.")]
        public bool Verbose { get; set; }
    }

    class Options
    {
        [Option('r', "read", Required = false, HelpText = "Input files to be processed.")]
        public IEnumerable<string> InputFiles { get; set; }

        [Option('v', "verbose", Required = false, HelpText = "Set output to verbose messages.")]
        public bool Verbose { get; set; }

        [Option("stdin",
            Default = false,
            HelpText = "Read from stdin")]
        public bool stdin { get; set; }

        [Value(0, MetaName = "offset", HelpText = "File offset.")]
        public long? Offset { get; set; }
    }

    [Verb("add", HelpText = "Add file contents to the index.")]
    class AddOptions
    {
        [Option('a', "add", Required = false, HelpText = "Input file to be added.")]
        public string FileName { get; set; }
    }

    [Verb("commit", HelpText = "Record changes to the repository.")]
    class CommitOptions
    {
        [Option('c', "commit", Required = false, HelpText = "Input file to be committed.")]
        public string FileName { get; set; }
    }

    [Verb("clone", HelpText = "Clone a repository into a new directory.")]
    class CloneOptions
    {
        [Option('l', "clone", Required = false, HelpText = "Input file to be cloned.")]
        public string FileName { get; set; }
    }
}