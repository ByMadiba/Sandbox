﻿using System;
using System.Collections.Generic;
using System.Linq;
using CommandLine;

namespace ZamaICommandLineParser
{
    class Program
    {
        static void Main(string[] args)
        {
            //// "--verbose true / -v true"
            //Parser.Default.ParseArguments<BasicsOptions>(args)
            //    .WithParsed<BasicsOptions>(o =>
            //    {
            //        if (o.Verbose)
            //        {
            //            Console.WriteLine($"Verbose output enabled. Current Arguments: -v {o.Verbose}");
            //            Console.WriteLine("Quick Start Example! App is in Verbose mode!");
            //        }
            //        else
            //        {
            //            Console.WriteLine($"Current Arguments: -v {o.Verbose}");
            //            Console.WriteLine("Quick Start Example!");
            //        }
            //    });

            // basic parser
            // "2 --read Test.txt --verbose"
            CommandLine.Parser.Default.ParseArguments<Options>(args)
                .WithParsed(RunOptions)
                .WithNotParsed(HandleParseError);

            // parser with return value
            var optionsAction = new OptionsWithActions();

            var number = CommandLine.Parser.Default.ParseArguments<Options>(args)
                .MapResult(
                    (Options opts) => optionsAction.RunAndReturnNumber(opts),
                    errs => 1);

            Console.WriteLine("Result is {0}", number);

            var result = Parser.Default.ParseArguments<Options>(args);

            var taskResult = optionsAction.RunAndReturnExitCode(result);

            Console.WriteLine("Task Result is {0}", taskResult.Result);



            //var result = Parser.Default.ParseArguments<Options>(args)
            //    .WithParsed(options => ExecuteSimulation(options)) // options is an instance of Options type
            //    .WithNotParsed(errors => HandleParseError(errors)); // errors is a sequence of type IEnumerable<Error>

            /*var results = Parser.Default.ParseArguments<Options>(args)
                .MapResult(
                    options => ExecuteSimulation(options),
                    errors => HandleParseError(errors));*/
            
            /*var results = Parser.Default.ParseArguments<Options>(args)
                .MapResult(
                    ExecuteSimulation,
                    HandleParseError);*/
        }

        static void RunOptions(Options opts)
        {
            //handle options
            Console.WriteLine(opts.InputFiles.First());
            Console.WriteLine(opts);

        }

        static void HandleParseError(IEnumerable<Error> errs)
        {
            //handle errors
            foreach (var error in errs)
            {
                Console.WriteLine(error);
            }
        }

        static int PrintToPrompt(Options opts, bool arbitrary)
        {
            Console.WriteLine(opts.InputFiles.First());

            return 777;
        }
    }
}
