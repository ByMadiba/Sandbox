﻿using System;
using System.Collections.Generic;
using System.Text;
using FluentAssertions;
using Xunit;
using Xunit.Abstractions;

namespace ZamaLokhuNalokhu
{
    /// <summary>
    /// The word Tuple means “a data structure which consists of the multiple parts”.
    /// So tuple is a data structure which gives you the easiest way to represent a data set which has multiple values that may/may not be related to each other
    /// </summary>
    public class ZamAmaTuples
    {
        private readonly ITestOutputHelper _testOutputHelper;

        public ZamAmaTuples(ITestOutputHelper testOutputHelper)
        {
            _testOutputHelper = testOutputHelper;
        }

        [Fact]
        public void TestNamedTuples()
        {
            var t = (Sum: 4.5, Count: 3);
            _testOutputHelper.WriteLine($"Sum of {t.Count} elements is {t.Sum}.");

            t.Sum.Should().Be(4.5, "tuple field with name Sum is set to 4.5");
            t.Count.Should().Be(3, "tuple field with name Sum is set to 3");

            (double Sum, int Count) d = (4.5, 3);
            _testOutputHelper.WriteLine($"Sum of {d.Count} elements is {d.Sum}.");

            d.Sum.Should().Be(4.5, "tuple field with name Sum is set to 4.5");
            d.Count.Should().Be(3, "tuple field with name Sum is set to 3");
        }

        [Fact]
        public void TestTupleAsParameter()
        {
            var person = Tuple.Create(1, "Jacob", "Zuma");
            var sut = DisplayTuple(person);

            sut.Should().NotBeNullOrEmpty("surname has been set");
            sut.Should().Be("Zuma", "as has been set");
        }

        string DisplayTuple(Tuple<int, string, string> person)
        {
            _testOutputHelper.WriteLine($"Id = { person.Item1}");
            _testOutputHelper.WriteLine($"First Name = { person.Item2}");
            _testOutputHelper.WriteLine($"Last Name = { person.Item3}");

            return person.Item3;
        }

        [Fact]
        public void TestNamesTupleAsParameter()
        {
            var instructionInfo = (InstructionID:9876543210, SettlementType: "CREDIT", ProcessingStatus: "SUBMITTED", ProcessingTime: DateTime.Now);
            var sut = UseNamedTuple(instructionInfo);

            sut.Should().BeTrue("testing a name tuple param");
        }

        bool UseNamedTuple((long InstructionID, string SettlementType, string ProcessingStatus, DateTime ProcessingTime) u)
        {
            _testOutputHelper.WriteLine($"{u.SettlementType} instruction [{u.InstructionID}] was processed at {u.ProcessingTime}");
            return !string.IsNullOrEmpty(u.SettlementType);
        }
    }
}
