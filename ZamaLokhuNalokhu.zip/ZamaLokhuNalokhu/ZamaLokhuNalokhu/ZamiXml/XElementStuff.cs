﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using FluentAssertions;
using Xunit;
using Xunit.Abstractions;

namespace ZamaLokhuNalokhu.ZamiXml
{
    public class XElementStuff
    {
        private readonly ITestOutputHelper _testOutputHelper;

        public XElementStuff(ITestOutputHelper testOutputHelper)
        {
            _testOutputHelper = testOutputHelper;
        }

        [Fact]
        public void TestCreateXElement()
        {
            XElement contacts =
                new XElement("Contacts",
                    new XElement("Contact",
                        new XElement("Name", "Che Guevara"),
                        new XElement("Phone", "777-555-4444"),
                        new XElement("Address",
                            new XElement("Street", "123 Main St"),
                            new XElement("City", "Ethekwini"),
                            new XElement("Province", "KwaZulu"),
                            new XElement("Postal", "4444")
                        )
                    ),
                    new XElement("Contact",
                        new XElement("Name", "Fidel Castro"),
                        new XElement("Phone", "111-444-5555"),
                        new XElement("Address",
                            new XElement("Street", "321 Main St"),
                            new XElement("City", "Emalahleni"),
                            new XElement("Province", "Mpumalanga"),
                            new XElement("Postal", "5555")
                        )
                    )
                );

            var outputs = from ele in contacts.Elements()
                select ele;

            foreach (var output in outputs)
            {
                output.Name.LocalName.Should().NotBeNullOrEmpty("named in initialization");
                _testOutputHelper.WriteLine("Name: {0}", output.Name.LocalName);
            }

            _testOutputHelper.WriteLine(contacts.ToString());
        }
    }
}
