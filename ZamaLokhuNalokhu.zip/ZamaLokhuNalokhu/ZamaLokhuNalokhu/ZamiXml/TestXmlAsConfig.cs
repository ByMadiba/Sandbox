﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using Xunit;

namespace ZamaLokhuNalokhu.ZamiXml
{
    public class TestXmlAsConfig
    {
        [Fact]
        public void TestTaxCredentials()
        {
			var newPassword = "fff0fff0fff0fff0";
            /* Key = OldCredentials; Value = NewCredentials */
			var taxCredentials = new Dictionary<string, string>
{

	{$"CH_INTEGRATION_BATCH:", $"CH_INTEGRATION_BATCH:{newPassword}@JSE"},
	{$"CH_INTEGRATION_BILLING:", $"CH_INTEGRATION_BILLING:{newPassword}@JSE"},
	{$"CH_INTEGRATION_BROKER:", $"CH_INTEGRATION_BROKER:{newPassword}@JSE"},
	{$"CH_INTEGRATION_CDD:", $"CH_INTEGRATION_CDD:{newPassword}@JSE"},
	{$"CH_INTEGRATION_CDU:", $"CH_INTEGRATION_CDU:{newPassword}@JSE"},
	{$"CH_INTEGRATION_COLLATERALMANAGEMENT:", $"CH_INTEGRATION_COLLATERALMANAGEMENT:{newPassword}@JSE"},
	{$"CH_INTEGRATION_DEAL:", $"CH_INTEGRATION_DEAL:{newPassword}@JSE"},
	{$"CH_INTEGRATION_EOD:", $"CH_INTEGRATION_EOD:{newPassword}@JSE"},
	{$"CH_INTEGRATION_OPENINTEREST:", $"CH_INTEGRATION_OPENINTEREST:{newPassword}@JSE"},
	{$"CH_INTEGRATION_POSITION:", $"CH_INTEGRATION_POSITION:{newPassword}@JSE"},
	{$"CH_INTEGRATION_PRICING:", $"CH_INTEGRATION_PRICING:{newPassword}@JSE"},
	{$"CH_INTEGRATION_PRICINGEVENTFLOW:", $"CH_INTEGRATION_PRICINGEVENTFLOW:{newPassword}@JSE"},
	{$"CH_INTEGRATION_RESUBMIT:", $"CH_INTEGRATION_RESUBMIT:{newPassword}@JSE"},
	{$"CH_INTEGRATION_RISKARRAY:", $"CH_INTEGRATION_RISKARRAY:{newPassword}@JSE"},
	{$"CH_INTEGRATION_RISKNODE:", $"CH_INTEGRATION_RISKNODE:{newPassword}@JSE"},
	{$"CH_INTEGRATION_SETTLEMENT:", $"CH_INTEGRATION_SETTLEMENT:{newPassword}@JSE"},
	{$"CH_INTEGRATION_TRADING:", $"CH_INTEGRATION_TRADING:{newPassword}@JSE"},
	{$"CH_LIVE_WEB_CALCULATOR:", $"CH_LIVE_WEB_CALCULATOR:{newPassword}@JSE"},
	{$"CH_INTEGRATION_LAYER2:", $"CH_INTEGRATION_LAYER2:{newPassword}@JSE"},

};

            var arbitrary = string.Empty;

				//foreach (var taxCred in taxCredentials)
				//{
				//	if (xml.credentials.Attribute("value").Value.Contains(taxCred.Key))
				//	{
				//		Console.WriteLine($"Old credentials = {xml.credentials.Attribute("value").Value} => New credentials = {taxCred.Value}.");

				//		xml.credentials.Attribute("value").SetValue(taxCred.Value);
				//	}
				//}
        }
    }
}
