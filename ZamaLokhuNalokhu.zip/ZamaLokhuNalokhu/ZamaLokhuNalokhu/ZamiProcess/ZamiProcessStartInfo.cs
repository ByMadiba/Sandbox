﻿using System;
using System.Diagnostics;
using System.IO;
using FluentAssertions;
using Xunit;
using Xunit.Abstractions;

namespace ZamaLokhuNalokhu.ZamiProcess
{
    /// <summary>
    /// ProcessStartInfo
    /// Specifies a set of values that are used when you start a process.
    /// </summary>
    public class ZamiProcessStartInfo
    {
        private readonly ITestOutputHelper _testOutputHelper;

        public ZamiProcessStartInfo(ITestOutputHelper testOutputHelper)
        {
            _testOutputHelper = testOutputHelper;
        }

        [Fact]
        public void TestProcessStartInfo_RedirectStandardOutput()
        {
            var jobPath = @"C:\Source\JSE\Enterprise Integration\Source\Applications\Batches\Jse.Ei.Batch.PostTrade\bin\Debug";
            var executablePath = $@"""{Path.Combine(jobPath, "Jse.Ei.Batch.PostTrade.exe")}""";
            string[] args = new[] { "/bc", "/bj", "InvalidTestNameWillCauseAnError" };

            Array.ForEach(args, _ => executablePath += $" {_}");

            string errorOut = null;
            string output = null;

            using (Process myProcess = new Process())
            {
                ProcessStartInfo myProcessStartInfo = new ProcessStartInfo
                {
                    FileName = "cmd.exe",
                    Arguments = "/C " + executablePath,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                };
                
                myProcess.ErrorDataReceived += new DataReceivedEventHandler((sender, e) =>
                    { errorOut += e.Data; });

                myProcess.StartInfo = myProcessStartInfo;
                myProcess.Start();

                // To avoid deadlocks, use an asynchronous read operation on at least one of the streams.  
                myProcess.BeginErrorReadLine();
                output = myProcess.StandardOutput.ReadToEnd();
                myProcess.WaitForExit();

                _testOutputHelper.WriteLine($"The output stream:\n'{output}'");
                _testOutputHelper.WriteLine($"\nError stream: {errorOut}");
            }

            output.Should().NotBeNullOrEmpty("Must redirect standard output");
        }

        /// <summary>
        /// When a Process writes text to its standard error stream, that text is typically displayed on the console.
        /// By redirecting the StandardError stream you can use or manipulate or suppress the error output of a process
        /// You must set UseShellExecute to false if you want to set RedirectStandardError to true
        /// </summary>
        [Fact]
        public void TestProcessStartInfo_RedirectStandardError()
        {
            string[] args = new[] { "/bc", "/bj", "InvalidTestNameWillCauseAnError" };
            
            string errorOut = null;

            using (Process myProcess = new Process())
            {
                ProcessStartInfo myProcessStartInfo = new ProcessStartInfo("net ", "use " + args[0]);

                myProcessStartInfo.UseShellExecute = false;
                myProcessStartInfo.RedirectStandardOutput = true;
                myProcessStartInfo.RedirectStandardError = true;

                myProcess.ErrorDataReceived += new DataReceivedEventHandler((sender, e) =>
                    { errorOut += e.Data; });

                myProcess.StartInfo = myProcessStartInfo;
                myProcess.Start();

                // To avoid deadlocks, use an asynchronous read operation on at least one of the streams.  
                myProcess.BeginErrorReadLine();
                myProcess.WaitForExit();

                _testOutputHelper.WriteLine($"\nError stream: {errorOut}");
            }

            errorOut.Should().NotBeNullOrEmpty("Must redirect standard output");
        }

        /// <summary>
        /// To make sure that WaitForExit really really waits for exit
        /// </summary>
        [Fact]
        public void TestProcessStartInfo_RedirectStandardOutput_WithLongRunningProcess()
        {
            var jobPath = @"C:\Source\JSE\Enterprise Integration\Source\Applications\Batches\Jse.Ei.Batch.PostTrade\bin\Debug";
            var executablePath = $@"""{Path.Combine(jobPath, "Jse.Ei.Batch.PostTrade.exe")}""";
            string[] args = new[] { "/bc", "/bj", "SendSettlementInstructionsIntraday" };

            Array.ForEach(args, _ => executablePath += $" {_}");

            string errorOut = null;
            string output = null;

            using (Process myProcess = new Process())
            {
                ProcessStartInfo myProcessStartInfo = new ProcessStartInfo
                {
                    FileName = "cmd.exe",
                    Arguments = "/C " + executablePath,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                };

                myProcess.ErrorDataReceived += new DataReceivedEventHandler((sender, e) =>
                    { errorOut += e.Data; });

                myProcess.StartInfo = myProcessStartInfo;
                myProcess.Start();

                // To avoid deadlocks, use an asynchronous read operation on at least one of the streams.  
                myProcess.BeginErrorReadLine();
                output = myProcess.StandardOutput.ReadToEnd();
                myProcess.WaitForExit();

                _testOutputHelper.WriteLine($"The output stream:\n'{output}'");
                _testOutputHelper.WriteLine($"\nError stream: {errorOut}");
            }

            output.Should().NotBeNullOrEmpty("Must redirect standard output");
        }

        /// <summary>
        ///  BeginErrorReadLine starts asynchronous read operations on the StandardError stream.
        /// This method enables a designated event handler for the stream output and immediately returns to the caller,
        /// which can perform other work while the stream output is directed to the event handler.
        ///  Note
        /// The application that is processing the asynchronous output should call the Process.WaitForExit method to ensure that the output buffer has been flushed.
        /// The following example shows how to read from a redirected error stream and wait for the child process to exit.
        /// It avoids a deadlock condition by calling p.StandardError.ReadToEnd before p.WaitForExit
        /// </summary>
        [Fact]
        public void TestProcessStartInfo_WithStandardOutput_Async()
        {
            var jobPath = @"C:\Source\JSE\Enterprise Integration\Source\Applications\Batches\Jse.Ei.Batch.PostTrade\bin\Debug";
            var executablePath = $@"""{Path.Combine(jobPath, "Jse.Ei.Batch.PostTrade.exe")}""";
            string[] args = new[] { "bc", "bj", "SendSettlementInstructionsIntraday" };

            Array.ForEach(args, _ => executablePath += $" {_}");

            using (Process myProcess = new Process())
            {
                ProcessStartInfo myProcessStartInfo = new ProcessStartInfo
                {
                    FileName = "cmd.exe",
                    Arguments = "/C " + executablePath,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                };

                myProcess.StartInfo = myProcessStartInfo;
                myProcess.Start();
                
                // To avoid deadlocks, always read the output stream first and then wait.  
                string output = myProcess.StandardOutput.ReadToEnd();
                myProcess.WaitForExit();

                _testOutputHelper.WriteLine($"Output stream: {output}");
                output.Should().NotBeNullOrEmpty("RedirectStandardOutput = true");
            }
        }

        [Fact]
        public void TestProcessStartInfo_WithStandardOutput_Sync()
        {
            var jobPath = @"C:\Source\JSE\Enterprise Integration\Source\Applications\Batches\Jse.Ei.Batch.PostTrade\bin\Debug";
            var executablePath = $@"""{Path.Combine(jobPath, "Jse.Ei.Batch.PostTrade.exe")}""";
            string[] args = new[] { "bc", "bj", "SendSettlementInstructionsIntraday" };

            Array.ForEach(args, _ => executablePath += $" {_}");

            using (Process myProcess = new Process())
            {
                ProcessStartInfo myProcessStartInfo = new ProcessStartInfo
                {
                    FileName = "cmd.exe",
                    Arguments = "/C " + executablePath,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                };

                myProcess.StartInfo = myProcessStartInfo;
                myProcess.Start();

                StreamReader myStreamReader = myProcess.StandardOutput;
                // Read the standard error of net.exe and write it on to console.
                _testOutputHelper.WriteLine(myStreamReader.ReadLine());
            }
        }

        /// <summary>
        /// Synchronous read operations introduce a dependency between the caller reading from the StandardError stream and the child process writing to that stream.
        /// These dependencies can cause deadlock conditions
        /// The deadlock condition results when the caller and child process wait for each other to complete an operation, and neither can continue
        /// </summary>
        [Fact]
        public void TestProcessStartInfo_WithStandardError_Sync()
        {
            var jobPath = @"C:\Source\JSE\Enterprise Integration\Source\Applications\Batches\Jse.Ei.Batch.PostTrade\bin\Debug";
            var executablePath = $@"""{Path.Combine(jobPath, "Jse.Ei.Batch.PostTrade.exe")}""";
            string[] args = new[] {"bc", "bj", "SendSettlementInstructionsIntraday"};

            Array.ForEach(args, _ => executablePath += $" {_}");

            using (Process myProcess = new Process())
            {
                ProcessStartInfo myProcessStartInfo = new ProcessStartInfo
                {
                    FileName = "cmd.exe",
                    Arguments = "/C " + executablePath,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                };

                myProcess.StartInfo = myProcessStartInfo;
                myProcess.Start();

                StreamReader myStreamReader = myProcess.StandardError;
                // Read the standard error of

                Action act = () => _testOutputHelper.WriteLine(myStreamReader.ReadLine());

                act.Should().Throw<ArgumentNullException>("Methods such as Read, ReadLine and ReadToEnd perform synchronous read operations on the error output stream of the process. These synchronous read operations do not complete until the associated Process writes to its StandardError stream, or closes the stream");
            }
        }
    }
}
