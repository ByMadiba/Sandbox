﻿using System;
using System.Collections.Generic;
using System.Text;
using FluentAssertions;
using Xunit;
using Xunit.Abstractions;

namespace ZamaLokhuNalokhu
{
    public class ZamiTimeSpanToString
    {
        private readonly ITestOutputHelper _testOutputHelper;

        public ZamiTimeSpanToString(ITestOutputHelper testOutputHelper)
        {
            _testOutputHelper = testOutputHelper;
        }

        [Fact]
        public void TestTimeSpanToString_WithNoFormatSpecified()
        {
            var timeOfDay = DateTime.Now.TimeOfDay;
            var timeString = timeOfDay.ToString();
            timeString.Should().NotBeNullOrEmpty("stringed the time");

            _testOutputHelper.WriteLine("Converted time with ToString() => {0}", timeString);
            timeString.IndexOf(':', StringComparison.CurrentCulture).Should().Be(2);
        }

        [Fact]
        public void TestTimeSpanToString_WithT()
        {
            var timeOfDay = DateTime.Now.TimeOfDay;
            var timeString = timeOfDay.ToString("t");
            timeString.Should().NotBeNullOrEmpty("stringed the time");

            _testOutputHelper.WriteLine("Converted time with t => {0}", timeString);
            timeString.IndexOf(':', StringComparison.CurrentCulture).Should().Be(2);

            var timeStringT = timeOfDay.ToString("T");
            timeStringT.Should().NotBeNullOrEmpty("stringed the time");

            _testOutputHelper.WriteLine("Converted time with T => {0}", timeStringT);
            timeStringT.IndexOf(':', StringComparison.CurrentCulture).Should().Be(2);
        }

        [Fact]
        public void TestTimeSpanToString_Withhhmmss()
        {
            var timeOfDay = DateTime.Now.TimeOfDay;
            var timeString = timeOfDay.ToString(@"hh\:mm\:ss");
            timeString.Should().NotBeNullOrEmpty("stringed the time");

            _testOutputHelper.WriteLine(@"Converted time with hh\:mm\:ss => {0}", timeString);
            timeString.IndexOf(':', StringComparison.CurrentCulture).Should().Be(2);
        }

        [Fact]
        public void TestTimeStampToString_WithSubstring()
        {
            var addMilliseconds = TimeSpan.FromMilliseconds(123456);
            var morning = new TimeSpan(8, 0, 1);
            var afternoon = new TimeSpan(15, 35, 36);
            morning = morning.Add(addMilliseconds);
            afternoon = afternoon.Add(addMilliseconds);

            _testOutputHelper.WriteLine("Morning time is {0}", morning);
            _testOutputHelper.WriteLine("Afternoon time is {0}", afternoon);

            var morningFormattedString = morning.ToString(@"hh\:mm\:ss\.ffffff");
            var afternoonFormattedString = afternoon.ToString("c");

            _testOutputHelper.WriteLine("Morning time as string {0}", morningFormattedString);
            _testOutputHelper.WriteLine("Afternoon string as string {0}", afternoonFormattedString);

            var morningString = morning.ToString(@"hhmmssffffff");
            var afternoonString = afternoon.ToString(@"hhmmssffffff");

            _testOutputHelper.WriteLine("Morning time formatted as string {0}", morningString);
            _testOutputHelper.WriteLine("Afternoon time formatted as string {0}", afternoonString);

            var morningSubstring = morningString.Substring(0, 10);
            var afternoonSubstring = afternoonString.Substring(0, 10);

            morningSubstring.Length.Should().Be(10, "thats what's specified");
            afternoonSubstring.Length.Should().Be(10, "thats what's specified");

            var morningNumeric = Convert.ToInt64(morningString);
            var afternoonNumeric = Convert.ToInt64(afternoonSubstring);

            _testOutputHelper.WriteLine("Morning time {0} is numeric value {1}", morning, morningNumeric);
            _testOutputHelper.WriteLine("Afternoon time {0} is numeric value {1}", afternoon, afternoonNumeric);

            var difference = afternoonNumeric - morningNumeric;
            _testOutputHelper.WriteLine("Difference (should be positive): {0}", difference);

            morningNumeric.Should().BeLessThan(afternoonNumeric, "08h00 is earlier than 15h00");
        }
    }
}
