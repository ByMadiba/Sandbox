﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FluentAssertions;
using Xunit;
using Xunit.Abstractions;

namespace ZamaLokhuNalokhu.ZamiAsynchronousProgramming
{
    /// <summary>
    /// You can cancel an async application if you don't want to wait for it to finish
    /// You can cancel many tasks by associating the CancellationTokenSource instance with each task
    /// </summary>
    public class ZamiCancellationToken
    {
        private readonly ITestOutputHelper _testOutputHelper;
        static readonly CancellationTokenSource s_cts = new CancellationTokenSource();

        static readonly HttpClient s_client = new HttpClient
        {
            MaxResponseContentBufferSize = 1_000_000
        };

        static readonly IEnumerable<string> s_urlList = new string[]
        {
            "https://docs.microsoft.com",
            "https://docs.microsoft.com/aspnet/core",
            "https://docs.microsoft.com/azure",
            "https://docs.microsoft.com/azure/devops",
            "https://docs.microsoft.com/dotnet",
            "https://docs.microsoft.com/dynamics365",
            "https://docs.microsoft.com/education",
            "https://docs.microsoft.com/enterprise-mobility-security",
            "https://docs.microsoft.com/gaming",
            "https://docs.microsoft.com/graph",
            "https://docs.microsoft.com/microsoft-365",
            "https://docs.microsoft.com/office",
            "https://docs.microsoft.com/powershell",
            "https://docs.microsoft.com/sql",
            "https://docs.microsoft.com/surface",
            "https://docs.microsoft.com/system-center",
            "https://docs.microsoft.com/visualstudio",
            "https://docs.microsoft.com/windows",
            "https://docs.microsoft.com/xamarin"
        };

        public ZamiCancellationToken(ITestOutputHelper testOutputHelper)
        {
            _testOutputHelper = testOutputHelper;
        }

        [Fact]
        public async void TestCancellationTokenBasedOnWhenAny_TokenTaskFinishedFirst_Cancelled()
        {
            _testOutputHelper.WriteLine("Application started.");
            
            Task sumPageSizesTask = SumPageSizesAsync();
            Task willCancelSoon = WillCancelTokenAfterAShortPeriod(1000);

            await Task.WhenAny(new[] { willCancelSoon, sumPageSizesTask });
            
            _testOutputHelper.WriteLine("Application ending.");

            s_cts.IsCancellationRequested.Should().BeTrue("cancelled it");
        }

        [Fact]
        public async void TestCancellationTokenBasedOnWhenAny_OtherTaskFinishesFirst_NotCancelled()
        {
            _testOutputHelper.WriteLine("Application started.");

            Task sumPageSizesTask = SumPageSizesAsync();
            Task willCancelSoon = WillCancelTokenAfterAShortPeriod(50000);

            await Task.WhenAny(new[] { willCancelSoon, sumPageSizesTask });

            _testOutputHelper.WriteLine("Application ending.");

            s_cts.IsCancellationRequested.Should().BeFalse("The other tasks will finish first as delay is set to 50000");
        }

        /// <summary>
        /// You can cancel an asynchronous operation after a period of time by using the CancellationTokenSource.CancelAfter method if you don't want to wait for the operation to finish.
        /// This method schedules the cancellation of any associated tasks that aren't complete within the period of time that's designated by the CancelAfter expression
        /// </summary>
        [Fact]
        public async void TestCancellationTokenCancelAfter()
        {
            _testOutputHelper.WriteLine("Application started.");
            var exceptionThrown = false;

            try
            {
                s_cts.CancelAfter(3500);

                await SumPageSizesAsync();
            }
            catch (OperationCanceledException)
            {
                exceptionThrown = true;
                _testOutputHelper.WriteLine("\nTasks cancelled: timed out.\n");
            }
            finally
            {
                s_cts.Dispose();
            }

            _testOutputHelper.WriteLine("Application ending.");
            exceptionThrown.Should().BeTrue("Token was cancelled after 3500ms");
        }

        [Fact]
        public async void TestCancelTokenEmvaKweSikhathi()
        {
            Func<Task> f = async () => { await CancelTokenEmvaKweSikhathi(3500); };
            _ = f.Should().ThrowAsync<TaskCanceledException>()
                .WithMessage("Tasks cancelled");
        }

        async Task SumPageSizesAsync()
        {
            var stopwatch = Stopwatch.StartNew();

            int total = 0;
            foreach (string url in s_urlList)
            {
                _testOutputHelper.WriteLine($"Processing {url}...");
                int contentLength = await ProcessUrlAsync(url, s_client, s_cts.Token);
                total += contentLength;
            }

            stopwatch.Stop();

            _testOutputHelper.WriteLine($"\nTotal bytes returned:  {total:#,#}");
            _testOutputHelper.WriteLine($"Elapsed time:          {stopwatch.Elapsed}\n");
        }

        [Fact]
        public async void TestProcessTasksAsTheyFinish()
        {
            var stopwatch = Stopwatch.StartNew();

            IEnumerable<Task<int>> downloadTasksQuery =
                from url in s_urlList
                select ProcessUrlAsync(url, s_client, s_cts.Token);

            List<Task<int>> downloadTasks = downloadTasksQuery.ToList();

            int total = 0;
            while (downloadTasks.Any())
            {
                Task<int> finishedTask = await Task.WhenAny(downloadTasks);
                downloadTasks.Remove(finishedTask);
                total += await finishedTask;
            }

            stopwatch.Stop();

            _testOutputHelper.WriteLine($"\nTotal bytes returned:  {total:#,#}");
            _testOutputHelper.WriteLine($"Elapsed time:          {stopwatch.Elapsed}\n");

            total.Should().BeGreaterThan(0, "processed in while loop");
        }

        async Task WillCancelTokenAfterAShortPeriod(int delay)
        {
            _testOutputHelper.WriteLine("External action will cancel the token after {0}ms...", delay);
            await Task.Delay(delay);
            AnActionThatCancelsTheToken();
        }

        async Task<int> ProcessUrlAsync(string url, HttpClient client, CancellationToken token)
        {
            HttpResponseMessage response = await client.GetAsync(url, token);
            byte[] content = await response.Content.ReadAsByteArrayAsync();
            _testOutputHelper.WriteLine($"{url,-60} {content.Length,10:#,#}");

            return content.Length;
        }

        void AnActionThatCancelsTheToken()
        {
            _testOutputHelper.WriteLine("Cancelling the token...");
            s_cts.Cancel();
        }

        public async Task CancelTokenEmvaKweSikhathi(int cancelAfter)
        {
            _testOutputHelper.WriteLine("Application started.");

            _testOutputHelper.WriteLine($"Calling token.CancelAfter({cancelAfter})");
            s_cts.CancelAfter(cancelAfter);

            await SumPageSizesAsync();

            _testOutputHelper.WriteLine("Application ending.");
        }
    }
}
