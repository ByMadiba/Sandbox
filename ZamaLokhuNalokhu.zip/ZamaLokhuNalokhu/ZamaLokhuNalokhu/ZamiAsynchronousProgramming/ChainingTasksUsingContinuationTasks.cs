﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using FluentAssertions;
using Xunit;
using Xunit.Abstractions;

namespace ZamaLokhuNalokhu.ZamiAsynchronousProgramming
{
    /// <summary>
    /// In asynchronous programming, it's common for one asynchronous operation, on completion, to invoke a second operation.
    /// Continuations allow descendant operations to consume the results of the first operation
    /// A continuation task (also known just as a continuation) is an asynchronous task that's invoked by another task, known as the antecedent, when the antecedent finishes.
    /// A continuation is a task that is created in the WaitingForActivation state. It is activated automatically when its antecedent task or tasks complete
    /// A continuation is itself a Task and does not block the thread on which it is started.
    ///     Call the Task.Wait method to block until the continuation task finishes.
    /// </summary>
    public class ChainingTasksUsingContinuationTasks
    {
        /*
        Continuations are relatively easy to use, but are nevertheless powerful and flexible. For example, you can:
	        Pass data from the antecedent to the continuation.
	        Specify the precise conditions under which the continuation will be invoked or not invoked.
	        Cancel a continuation either before it starts or cooperatively as it is running.
	        Provide hints about how the continuation should be scheduled.
	        Invoke multiple continuations from the same antecedent.
	        Invoke one continuation when all or any one of multiple antecedents complete.
	        Chain continuations one after another to any arbitrary length.
	        Use a continuation to handle exceptions thrown by the antecedent.
        */

        private readonly ITestOutputHelper _testOutputHelper;

        public ChainingTasksUsingContinuationTasks(ITestOutputHelper testOutputHelper)
        {
            _testOutputHelper = testOutputHelper;
        }

        /// <summary>
        /// You create a continuation that executes when its antecedent has completed by calling the Task.ContinueWith method.
        /// </summary>
        [Fact]
        public async void TestContinuationForSingleAntecedent()
        {
            //var output = DayOfWeek.Monday;
            DayOfWeek? output = null;
            var dayOfTheWeek = DateTime.Today.DayOfWeek;

            // Declare, assign, and start the antecedent task.
            Task<DayOfWeek> taskA = Task.Run(() => DateTime.Today.DayOfWeek);

            // Execute the continuation when the antecedent finishes.
            await taskA.ContinueWith(antecedent => output = antecedent.Result);

            output.Should().NotBeNull("populated in Continue");
            output.Should().Be(dayOfTheWeek);
        }

        /// <summary>
        /// The following example calls the Task.WhenAll(IEnumerable<Task>) method to create a continuation task that reflects the results of its 10 antecedent tasks
        /// You can also create a continuation that will run when any or all of a group of tasks has completed
        /// Use static Task.WhenAll method or the instance TaskFactory.ContinueWhenAll method OR
        /// static Task.WhenAny method or the instance TaskFactory.ContinueWhenAny method.
        /// Calls to the Task.WhenAll and Task.WhenAny overloads do not block the calling thread.
        /// However, you typically call all but the Task.WhenAll(IEnumerable<Task>) and Task.WhenAll(Task[]) methods
        /// to retrieve the returned Task<TResult>.Result property, which does block the calling thread.
        /// </summary>
        [Fact]
        public async void TestContinuationForMultipleAntecedents()
        {
            var tasks = new List<Task<int>>();
            for (int ctr = 1; ctr <= 10; ctr++)
            {
                int baseValue = ctr;
                tasks.Add(Task.Factory.StartNew(b => (int)b! * (int)b, baseValue));
            }

            var results = await Task.WhenAll(tasks);

            int sum = 0;
            for (int ctr = 0; ctr <= results.Length - 1; ctr++)
            {
                var result = results[ctr];
                _testOutputHelper.WriteLine($"{result} {((ctr == results.Length - 1) ? "=" : "+")} ");
                sum += result;
            }

            _testOutputHelper.WriteLine("The sum is {0}", sum);
            sum.Should().BeGreaterThan(0, "Tasks have worked it");
        }

        /// <summary>
        /// The Task.ContinueWith method passes a reference to the antecedent to the user delegate of the continuation as an argument.
        /// If the antecedent is a System.Threading.Tasks.Task<TResult> object, and the task ran until it was completed,
        /// then the continuation can access the Task<TResult>.Result property of the task.
        /// The Task<TResult>.Result property blocks until the task has completed
        ///     However, if the task was canceled or faulted, attempting to access the Result property throws an AggregateException exception
        ///     You can avoid this problem by using the OnlyOnRanToCompletion option
        /// </summary>
        [Fact]
        public async void TestPassDataToContinuation()
        {
            var output = string.Empty;

            var task = Task.Run(
                () =>
                {
                    DateTime date = DateTime.Now;
                    output =  date.Hour > 17
                        ? "evening"
                        : date.Hour > 12
                            ? "afternoon"
                            : "morning";
                    return output;
                });

            await task.ContinueWith(
                antecedent =>
                {
                    _testOutputHelper.WriteLine($"Good {antecedent.Result}!");
                    _testOutputHelper.WriteLine($"And how are you this fine {antecedent.Result}?");
                    antecedent.Result.Should().Be(output);
                }, TaskContinuationOptions.OnlyOnRanToCompletion);

            output.Should().NotBeNullOrEmpty("populated in antecedent");
        }

        /// <summary>
        /// If you want the continuation to run even if the antecedent did not run to successful completion, you must guard against the exception
        /// One approach is to test the Task.Status property of the antecedent, and only attempt to access the Result property if the status is not Faulted or Canceled.
        /// You can also examine the Exception property of the antecedent.
        /// </summary>
        [Fact]
        public async void TestPassDataToContinuation_WithAntecedentFailHandling()
        {
            var output = string.Empty;
            var exceptionThrown = false;

            await Task.Run(
                    () =>
                    {
                        DateTime date = DateTime.Now;
                        output = date.Hour > 17
                            ? "evening"
                            : date.Hour > 12
                                ? "afternoon"
                                : "morning";
                        return output;
                    })
                .ContinueWith(
                    antecedent =>
                    {
                        if (antecedent.Status == TaskStatus.RanToCompletion)
                        {
                            _testOutputHelper.WriteLine($"Good {antecedent.Result}!");
                            _testOutputHelper.WriteLine($"And how are you this fine {antecedent.Result}?");
                        }
                        else if (antecedent.Status == TaskStatus.Faulted)
                        {
                            exceptionThrown = true;
                            _testOutputHelper.WriteLine(antecedent.Exception!.GetBaseException().Message);
                        }
                    });

            output.Should().NotBeNullOrEmpty("populated in antecedent");
            exceptionThrown.Should().BeFalse("no exception should be thrown");
        }

        /// <summary>
        /// The Task.Status property of a continuation is set to TaskStatus.Canceled in the following situations:
        ///     It throws an OperationCanceledException exception in response to a cancellation request
        ///     The continuation is passed a System.Threading.CancellationToken whose IsCancellationRequested property is true
        ///         In this case, the continuation does not start, and it transitions to the TaskStatus.Canceled state
        ///     The continuation never runs because the condition set by its TaskContinuationOptions argument was not met
        /// </summary>
        
        /// <summary>
        /// If the condition is not true when the antecedent is ready to invoke the continuation,
        /// the continuation transitions directly to the TaskStatus.Canceled state and subsequently cannot be started.
        /// </summary>
        [Fact]
        public async void TestContinuationWithContinuationOptions()
        {

        }

        [Fact]
        public async void TestChainingWithContinuation()
        {

        }

        async Task FirstTask()
        {
            await Task.Delay(2000);
        }

        async Task SecondTask()
        {
            await Task.Delay(2000);
        }

        async Task ThirdTask()
        {
            await Task.Delay(2000);
        }
    }
}
