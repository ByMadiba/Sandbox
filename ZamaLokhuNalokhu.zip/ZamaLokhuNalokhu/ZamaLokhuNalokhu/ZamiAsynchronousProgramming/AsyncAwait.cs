﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using FluentAssertions;
using Xunit;
using Xunit.Abstractions;

namespace ZamaLokhuNalokhu.ZamiAsynchronousProgramming
{
    /// <summary>
    /// Don't block, await instead
    /// The await keyword provides a non-blocking way to start a task, then continue execution when that task completes
    /// It's better to start each of the component tasks before awaiting the previous task's completion.
    /// You await each task before using its result.
    /// async modifier signals to the compiler that this method contains an await statement; it contains asynchronous operations.
    /// https://docs.microsoft.com/en-us/dotnet/csharp/programming-guide/concepts/async/
    /// </summary>
    public class AsyncAwait
    {
        private readonly ITestOutputHelper _testOutputHelper;

        /// <summary>
        /// Cooking breakfast is a good example of asynchronous work that isn't parallel. One person (or thread) can handle all these tasks.
        /// For a parallel algorithm, you'd need multiple cooks (or threads). One would make the eggs, one the bacon, and so on.
        /// Each one would be focused on just that one task. Each cook (or thread) would be blocked synchronously waiting for the bacon to be ready to flip, or the toast to pop
        /// ***
        /// As each Task requires action, you'd turn your attention to that task, take care of the next action, then wait for something else that requires your attention.
        /// You start a task and hold on to the Task object that represents the work.
        /// You'll await each task before working with its result.
        /// </summary>
        /// <param name="testOutputHelper"></param>
        public AsyncAwait(ITestOutputHelper testOutputHelper)
        {
            _testOutputHelper = testOutputHelper;
            //Don't block, await instead
        }

        /// <summary>
        /// Pour a cup of coffee.
        /// Heat a pan, then fry two eggs.
        /// Fry three slices of bacon.
        /// Toast two pieces of bread.
        /// Add butter and jam to the toast.
        /// Pour a glass of orange juice.
        /// </summary>
        [Fact]
        public async void TestMakeBreakfastAsync()
        {
            Coffee cup = PourCoffee();
            _testOutputHelper.WriteLine("coffee is ready");

            // you want to start several independent tasks immediately.
            // Then, as each task finishes, you can continue other work that's ready
            // You also get everything done close to the same time

            var eggsTask = FryEggsAsync(2);
            var baconTask = FryBaconAsync(3);
            var toastTask = MakeToastWithButterAndJamAsync(2);

            // The first step is to store the tasks for operations when they start, rather than awaiting them
            var breakfastTasks = new List<Task> { eggsTask, baconTask, toastTask };

            // Next, you can move the await statements for the bacon and eggs to the end of the method, before serving breakfast
            while (breakfastTasks.Count > 0)
            {
                Task finishedTask = await Task.WhenAny(breakfastTasks);
                if (finishedTask == eggsTask)
                {
                    _testOutputHelper.WriteLine("eggs are ready");
                }
                else if (finishedTask == baconTask)
                {
                    _testOutputHelper.WriteLine("bacon is ready");
                }
                else if (finishedTask == toastTask)
                {
                    _testOutputHelper.WriteLine("toast is ready");
                }
                breakfastTasks.Remove(finishedTask);
            }

            Juice oj = PourOJ();
            _testOutputHelper.WriteLine("oj is ready");
            _testOutputHelper.WriteLine("Breakfast is ready!");
        }

        [Fact]
        public async void TestMakeBreakfastAsync_WithError()
        {
            Coffee cup = PourCoffee();
            _testOutputHelper.WriteLine("coffee is ready");

            // you want to start several independent tasks immediately.
            // Then, as each task finishes, you can continue other work that's ready
            // You also get everything done close to the same time

            var eggsTask = FryEggsAsync(2);
            var baconTask = FryBaconAsync(3);
            var toastTask = ToastBreadAsync(2, true); // this method throws exception

            // The first step is to store the tasks for operations when they start, rather than awaiting them
            var breakfastTasks = new List<Task> { eggsTask, baconTask, toastTask };

            // Next, you can move the await statements for the bacon and eggs to the end of the method, before serving breakfast
            while (breakfastTasks.Count > 0)
            {
                Task finishedTask = await Task.WhenAny(breakfastTasks);
                if (finishedTask == eggsTask)
                {
                    _testOutputHelper.WriteLine("eggs are ready");
                }
                else if (finishedTask == baconTask)
                {
                    _testOutputHelper.WriteLine("bacon is ready");
                }
                else if (finishedTask == toastTask)
                {
                    _testOutputHelper.WriteLine("toast is ready");
                }
                breakfastTasks.Remove(finishedTask);
            }

            Juice oj = PourOJ();
            _testOutputHelper.WriteLine("oj is ready");
            _testOutputHelper.WriteLine("Breakfast is ready!");
            toastTask.Status.Should().Be(TaskStatus.Faulted, "Toast on fire");
            toastTask.Exception.InnerExceptions.Any().Should().BeTrue("Toast is on fire");
            toastTask.Exception.InnerExceptions.First().GetType().Should().Be(typeof(InvalidOperationException),
                "thats the exception we threw when the toast caught fire");

        }

        [Fact]
        public async void TestWhenAllVsWhenAny()
        {
            var sw = Stopwatch.StartNew();

            var eggsTask = FryEggsAsync(2);
            var baconTask = FryBaconAsync(3);
            var toastTask = ToastBreadAsync(2);

            await Task.WhenAll(eggsTask, baconTask, toastTask);
            _testOutputHelper.WriteLine("Eggs are ready");
            _testOutputHelper.WriteLine("Bacon is ready");
            _testOutputHelper.WriteLine("Toast is ready");
            _testOutputHelper.WriteLine("Breakfast is ready!");

            var whenAllTime = sw.ElapsedMilliseconds;
            _testOutputHelper.WriteLine("WhenAll completed in {0}ms", whenAllTime);

            sw.Restart();

            var eggsTaskAny = FryEggsAsync(2);
            var baconTaskAny = FryBaconAsync(3);
            var toastTaskAny = ToastBreadAsync(2);

            await Task.WhenAny(eggsTaskAny, baconTaskAny, toastTaskAny);
            _testOutputHelper.WriteLine("Eggs are ready");
            _testOutputHelper.WriteLine("Bacon is ready");
            _testOutputHelper.WriteLine("Toast is ready");
            _testOutputHelper.WriteLine("Breakfast is ready!");
            
            var whenAnyTime = sw.ElapsedMilliseconds;
            _testOutputHelper.WriteLine("WhenAny completed in {0}ms", whenAnyTime);

            whenAnyTime.Should()
                .BeLessThan(whenAllTime, "Waiting for any (1) should take less time than waiting for all");
        }
        
        /// <summary>
        /// Making the toast is the composition of an asynchronous operation (toasting the bread), and synchronous operations (adding the butter and the jam)
        /// Important
        /// The composition of an asynchronous operation followed by synchronous work is an asynchronous operation.
        /// Stated another way, if any portion of an operation is asynchronous, the entire operation is asynchronous
        /// </summary>
        /// <param name="number">number of slices</param>
        /// <returns>This method returns a Task<TResult> that represents the composition of those three operations</returns>
        async Task<Toast> MakeToastWithButterAndJamAsync(int number)
        {
            // you can use Task or Task<TResult> objects to hold running tasks
            // You await each task before using its result
            var toast = await ToastBreadAsync(number);
            ApplyButter(toast);
            ApplyJam(toast);

            return toast;
        }

        private Juice PourOJ()
        {
            _testOutputHelper.WriteLine("Pouring orange juice");
            return new Juice();
        }

        private void ApplyJam(Toast toast) =>
            _testOutputHelper.WriteLine("Putting jam on the toast");

        private void ApplyButter(Toast toast) =>
            _testOutputHelper.WriteLine("Putting butter on the toast");

        private async Task<Toast> ToastBreadAsync(int slices)
        {
            for (int slice = 0; slice < slices; slice++)
            {
                _testOutputHelper.WriteLine("Putting a slice of bread in the toaster");
            }
            _testOutputHelper.WriteLine("Start toasting...");
            await Task.Delay(3000);
            _testOutputHelper.WriteLine("Remove toast from toaster");

            return new Toast();
        }
        private async Task<Toast> ToastBreadAsync(int slices, bool imJustOverloadingSoICanCompile)
        {
            for (int slice = 0; slice < slices; slice++)
            {
                _testOutputHelper.WriteLine("Putting a slice of bread in the toaster");
            }
            _testOutputHelper.WriteLine("Start toasting...");
            await Task.Delay(2000);
            _testOutputHelper.WriteLine("Fire! Toast is ruined!");
            throw new InvalidOperationException("The toaster is on fire");
            await Task.Delay(1000);
            _testOutputHelper.WriteLine("Remove toast from toaster");

            return new Toast();
        }

        private async Task<Bacon> FryBaconAsync(int slices)
        {
            _testOutputHelper.WriteLine($"putting {slices} slices of bacon in the pan");
            _testOutputHelper.WriteLine("cooking first side of bacon...");
            await Task.Delay(3000);
            for (int slice = 0; slice < slices; slice++)
            {
                _testOutputHelper.WriteLine("flipping a slice of bacon");
            }
            _testOutputHelper.WriteLine("cooking the second side of bacon...");
            await Task.Delay(3000);
            _testOutputHelper.WriteLine("Put bacon on plate");

            return new Bacon();
        }

        private async Task<Egg> FryEggsAsync(int howMany)
        {
            _testOutputHelper.WriteLine("Warming the egg pan...");
            await Task.Delay(3000);
            _testOutputHelper.WriteLine($"cracking {howMany} eggs");
            _testOutputHelper.WriteLine("cooking the eggs ...");
            await Task.Delay(3000);
            _testOutputHelper.WriteLine("Put eggs on plate");

            return new Egg();
        }

        private Coffee PourCoffee()
        {
            _testOutputHelper.WriteLine("Pouring coffee");
            return new Coffee();
        }

    }

    // These classes are intentionally empty for the purpose of this example. They are simply marker classes for the purpose of demonstration, contain no properties, and serve no other purpose.
    internal class Bacon { }
    internal class Coffee { }
    internal class Egg { }
    internal class Juice { }
    internal class Toast { }
}
