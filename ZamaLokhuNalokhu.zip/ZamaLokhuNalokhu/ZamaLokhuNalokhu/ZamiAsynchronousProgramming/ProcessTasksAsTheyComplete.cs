﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using FluentAssertions;
using Xunit;
using Xunit.Abstractions;

namespace ZamaLokhuNalokhu.ZamiAsynchronousProgramming
{
    public class ProcessTasksAsTheyComplete
    {
        private readonly ITestOutputHelper _testOutputHelper;

        public ProcessTasksAsTheyComplete(ITestOutputHelper testOutputHelper)
        {
            _testOutputHelper = testOutputHelper;
        }

        async Task<object> TaskYokuBala(int delay)
        {
            await Task.Delay(delay);
            return delay * 7;
        }

        async Task<object> TaskYeQiniso(int delay)
        {
            await Task.Delay(delay);
            return true;
        }

        async Task<object> TaskYokuKhuluma(int delay)
        {
            await Task.Delay(delay);
            return "kwasha kwacima";
        }

        async Task<object> TaskEnePhutha(int delay)
        {
            await Task.Delay(delay);
            throw new InvalidOperationException("Ayeye!");
        }

        [Fact]
        public void thisStupidThing()
        {
            var tasks = new[] {
                Task.Delay(3000).ContinueWith(_ => 3),
                Task.Delay(1000).ContinueWith(_ => 1),
                Task.Delay(2000).ContinueWith(_ => 2),
                Task.Delay(5000).ContinueWith(_ => 5),
                Task.Delay(4000).ContinueWith(_ => 4),
            };
        }

        /// <summary>
        /// this code ends up processing the tasks in the order they were supplied rather than in the order they complete
        /// which means some tasks that have already completed might not be made available for processing,
        /// because an earlier task in the order may not have completed yet
        /// </summary>
        [Fact]
        public async void TestProcessResults_InOrderTheyAreSupplied()
        {
            int delay = 100;
            var output = string.Empty;

            var bala = TaskYokuBala(delay);
            var iqiniso = TaskYeQiniso(delay);
            var thetha = TaskYokuKhuluma(delay);

            var tasks = new List<Task<object>> { bala, iqiniso, thetha };

            foreach (var t in tasks)
            {
                try { output = Process(await t); }
                catch (OperationCanceledException) { }
                catch (Exception exc) { _testOutputHelper.WriteLine(exc.Message); }
            }

            output.Should().NotBeNullOrEmpty("Processed output");
        }

        [Fact]
        public async void TestProcessResults_InOrderTheyAreSupplied_WithException()
        {
            int delay = 100;
            var output = string.Empty;
            var exceptionThrown = false;

            var bala = TaskYokuBala(delay);
            var iqiniso = TaskYeQiniso(delay);
            var thetha = TaskYokuKhuluma(delay);
            var iphutha = TaskEnePhutha(delay);

            var tasks = new List<Task<object>> { bala, iqiniso, thetha, iphutha };

            foreach (var t in tasks)
            {
                try { output = Process(await t); }
                catch (OperationCanceledException) { }
                catch (Exception exc)
                {
                    exceptionThrown = true;
                    output = exc.Message;
                }
            }

            exceptionThrown.Should().BeTrue("TaskEnePhutha throws an exception");
            output.Should().NotBeNullOrEmpty("Processed output");
        }

        [Fact]
        public async void TestProcessResults_InOrderTheyAreCompleted()
        {
            int delay = 100;
            int delayLittle = 1;
            var output = string.Empty;
            var exceptionThrown = false;

            var bala = TaskYokuBala(delayLittle);
            var iqiniso = TaskYeQiniso(delay);
            var thetha = TaskYokuKhuluma(delay);
            var iphutha = TaskEnePhutha(delay);

            var tasks = new List<Task<object>> { bala, iqiniso, thetha };

            while (tasks.Count > 0)
            {
                var t = await Task.WhenAny(tasks);
                tasks.Remove(t);
                try { output = string.Concat(output, Process(await t)); }
                catch (OperationCanceledException) { }
                catch (Exception exc)
                {
                    exceptionThrown = true; 
                    output = Handle(exc); }
            }

            output.Should().NotBeNullOrEmpty("Processed output");
            output.Should().StartWith("7", "TaskYokuBala(1 * 7 = 7) should finish first as it has the littlest delay");
            exceptionThrown.Should().BeFalse("no exceptions expected");
        }

        [Fact]
        public async void TestProcessResults_InOrderTheyAreCompleted_WithException()
        {
            int delay = 100;
            int delayLittle = 1;
            var output = string.Empty;
            var exceptionThrown = false;

            var bala = TaskYokuBala(delay);
            var iqiniso = TaskYeQiniso(delayLittle);
            var thetha = TaskYokuKhuluma(delay);
            var iphutha = TaskEnePhutha(delay);

            var tasks = new List<Task<object>> { bala, iqiniso, thetha, iphutha };

            while (tasks.Count > 0)
            {
                var t = await Task.WhenAny(tasks);
                tasks.Remove(t);
                try { output = string.Concat(output, Process(await t)); }
                catch (OperationCanceledException) { }
                catch (Exception exc)
                {
                    exceptionThrown = true;
                    output += Handle(exc);
                }
            }

            output.Should().NotBeNullOrEmpty("Processed output");
            output.Should().StartWith("True", "TaskYeQiniso(true) should finish first as it has the littlest delay");
            exceptionThrown.Should().BeTrue("TaskEnePhutha threw an exceptions");
        }


        string Process(object tResult)
        {
            var output = $"{tResult}";
            _testOutputHelper.WriteLine(output);
            return output;
        }

        string Handle(Exception e)
        {
            return e.Message;
        }
    }
}
