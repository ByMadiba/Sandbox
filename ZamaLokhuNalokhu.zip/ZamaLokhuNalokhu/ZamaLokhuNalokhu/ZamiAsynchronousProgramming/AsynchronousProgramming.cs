﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using FluentAssertions;
using Xunit;
using Xunit.Abstractions;

namespace ZamaLokhuNalokhu
{
    /// <summary>
    /// If you have any I/O-bound needs (such as requesting data from a network, accessing a database, or reading and writing to a file system), you'll want to utilize asynchronous programming.
    /// You could also have CPU-bound code, such as performing an expensive calculation, which is also a good scenario for writing async code
    /// Known as the Task-based Asynchronous Pattern (TAP)
    /// The core of async programming is the Task and Task<T> objects, which model asynchronous operations. They are supported by the async and await keywords. The model is fairly simple in most cases:
    /// For I/O-bound code, you await an operation that returns a Task or Task<T> inside of an async method.
    /// For CPU-bound code, you await an operation that is started on a background thread with the Task.Run method.
    /// The await keyword is where the magic happens. It yields control to the caller of the method that performed await,
    /// and it ultimately allows a Process to be responsive or a service to be elastic.
    /// While there are ways to approach async code other than async and await, this test class focuses on the language-level constructs.
    /// ********************************
    /// Will your code be "waiting" for something, such as data from a database?
    ///     If your answer is "yes", then your work is I/O-bound.
    /// Will your code be performing an expensive computation?
    ///     If you answered "yes", then your work is CPU-bound.
    /// If the work you have is I/O-bound, use async and await without Task.Run. You should not use the Task Parallel Library
    /// If the work you have is CPU-bound and you care about responsiveness, use async and await, but spawn off the work on another thread with Task.Run
    /// ********************************
    /// async methods need to have an await keyword in their body or they will never yield!
    /// Add "Async" as the suffix of every async method name you write
    /// async void should only be used for event handlers
    ///     Exceptions thrown in an async void method can't be caught outside of that method
    ///     async void methods are difficult to test
    ///     async void methods can cause bad side effects if the caller isn't expecting them to be async
    /// !! Write code that awaits Tasks in a non-blocking manner
    /// Don't depend on the state of global objects or the execution of certain methods
    /// Instead, depend only on the return values of methods
    /// *********************************
    /// Futures and promises
    /// In computer science, future, promise, delay, and deferred refer to constructs used for synchronizing program execution in some concurrent programming languages.
    /// They describe an object that acts as a proxy for a result that is initially unknown, usually because the computation of its value is not yet complete.
    /// </summary>
    public class AsynchronousProgramming
    {
        private readonly ITestOutputHelper _testOutputHelper;

        public AsynchronousProgramming(ITestOutputHelper testOutputHelper)
        {
            _testOutputHelper = testOutputHelper;
        }

        [Fact]
        public void TestTaskStatusFaulted()
        {
            var sut = File.ReadAllLinesAsync("IncorrectFile.txt");

            _testOutputHelper.WriteLine(sut.Status.ToString());

            sut.Status.Should().Be(TaskStatus.Faulted, "Incorrect file name specified");
        }

        /// <summary>
        /// Tasks throw exceptions when they can't complete successfully
        /// </summary>
        [Fact]
        public void TestTaskStatusFaulted_WithException()
        {
            File.ReadAllLinesAsync(@"Samples\Sample.txt")
                .ContinueWith(t =>
                {
                    t.IsFaulted.Should().BeTrue("Incorrect file name specified");
                    t.Exception.Should().NotBeNull("IO FileNotFound Exception thrown for incorrect file name");
                });
        }

        [Fact]
        public void TestTaskStatus()
        {
            var fileReadTask = File.ReadAllLinesAsync(@"Samples\Sample.txt");

            _testOutputHelper.WriteLine(fileReadTask.Status.ToString()); // WaitingForActivation

            fileReadTask.Status.Should().Be(TaskStatus.WaitingForActivation,
                "It's a large file and we're just getting started");

            Thread.Sleep(1);

            _testOutputHelper.WriteLine(fileReadTask.Status.ToString()); // RanToCompletion Amazing! Just one ms

            fileReadTask.Status.Should().Be(TaskStatus.RanToCompletion,
                "We have waited 1ms, this is enough time to complete reading the file");
        }

        /// <summary>
        /// The Result property is a blocking property.
        /// If you try to access it before its task is finished, the thread that's currently active is blocked until the task completes and the value is available.
        /// In most cases, you should access the value by using await instead of accessing the property directly.
        /// </summary>
        [Fact]
        public void TestTaskContinueWith()
        {
            var output = new List<string>();

            File.ReadAllLinesAsync(@"Samples\Sample.txt")
                .ContinueWith(t =>
                {
                    // Task will be completed
                    // ContinueWith is scheduling the next part
                    // can access the task result

                    foreach (var line in t.Result) // Result BLOCKS the CPU that's why it does not show
                    {
                        output.Add(line);
                    }
                });
            output.Add("We are here now at the end of the road");

            /* ABOVE: ReadAllLines is not complete yet when ContinueWith runs. i.e. Schedules it BUT it immediately continues
             * So the "last line" is actually executed first
             */
            output.Any().Should().BeTrue();
            output.First().Should().Contain("end of the road",
                "Async Task is SCHEDULED but not RUN. It will immediately Continue",
                "i.e. ContinueWith Schedules it but Caller immediately continues execution",
                "hence the quote unquote last line is executed first",
                "The last shall be first (LOL)");
        }

        /*
         * Now that we see the problem with Tasks, time to introduce async and await :)
         */

        [Fact]
        public void TestReadFileAsync()
        {
            Action sut = async () => await ReadFileAsync();
            sut.Invoke();

            Func<Task<int>> getDataFromNetworkLambda = async () =>
            {
                // simulate a network call
                await Task.Delay(150); // NB! Will not block the CPU // .Delay won't block the thread, but will free the thread // hey C# if you have anything else to do, go ahead and do it

                // once above task is finished, continue with below
                var result = 47;

                _testOutputHelper.WriteLine($"The result is {result}");
                return result;
            };
            getDataFromNetworkLambda.Invoke();
            true.Should().BeTrue("Nothing really we can assert here");
        }

        [Fact]
        public void TestSyncVsAsyncReadFile()
        {
            var sw = Stopwatch.StartNew();
            ReadFile();
            var sutSync = sw.ElapsedMilliseconds;

            sw.Restart();
            Action sut = async () => await ReadFileAsync();
            sut.Invoke();
            var sutAsync = sw.ElapsedMilliseconds;

            _testOutputHelper.WriteLine(@"Sync took {0}, Async took {1}", sutSync, sutAsync);

            sutSync.Should().BeGreaterThan(sutAsync,
                "That's basically the point on async reading isn't it. Why spawn all these threads & work up the ThreadPool for mahala?");
        }

        void ReadFile()
        {
            var lines = File.ReadAllLines(@"Samples\Sample.txt");
            foreach (var line in lines)
            {
                // _testOutputHelper.WriteLine(line);
                Thread.Sleep(1);
            }
        }

        async Task ReadFileAsync()
        {
            var lines = await File.ReadAllLinesAsync(@"Samples\Sample.txt");
            
            foreach (var line in lines)
            {
                // _testOutputHelper.WriteLine(line);
                Task.Delay(1);
            }
        }

        /*
        Key pieces to understand
        Async code can be used for both I/O-bound and CPU-bound code, but differently for each scenario.
        Async code uses Task<T> and Task, which are constructs used to model work being done in the background.
        The async keyword turns a method into an async method, which allows you to use the await keyword in its body.
        When the await keyword is applied, it suspends the calling method and yields control back to its caller until the awaited task is complete.
        await can only be used inside an async method.
        */

        /// <summary>
        /// I/O-bound example
        /// Download data from a web service
        /// </summary>
        [Fact]
        public void TestIOBoundAsync()
        {
            HttpClient _httpClient = new HttpClient();
            var URL = @"https://dotnetfoundation.org/";

            Func<Task<int>> asyncTest = async () =>
            {
                // This line will yield control to the UI as the request
                // from the web service is happening.
                //
                // The UI thread is now free to perform other work.
                var getDotNetFoundationHtmlTask = _httpClient.GetStringAsync(URL);
                DoIndependentWork();
                var html = await getDotNetFoundationHtmlTask;
                int count = Regex.Matches(html, @"\.NET").Count;

                _testOutputHelper.WriteLine($"Number of .NETs on dotnetfoundation.org: {count}");
                return count;
            };

            asyncTest.Invoke();

        }

        int DoIndependentWork()
        {
            var result = 1;

            for (int i = 0; i < 10; i++)
            {
                result += (i * 7);
                Thread.Sleep(7);
            }

            return result;
        }

        /// <summary>
        /// On the C# side of things, the compiler transforms your code into a state machine that keeps track of things
        /// like yielding execution when an await is reached and resuming execution when a background job has finished
        /// </summary>
        [Fact]
        public void TestCPUBoundAsync()
        {
            string damageResult = string.Empty;

            Func<Task<int>> asyncTest = async () =>
            {
                // This line will yield control to the UI while CalculateDamageDone()
                // performs its work. The UI thread is free to perform other work.
                damageResult = await Task.Run(() => CalculateDamageDone());
                _testOutputHelper.WriteLine(damageResult);
                return 1;
            };

            asyncTest.Invoke();
            damageResult.Should().NotBeNullOrEmpty("ran");
        }
        
        private string CalculateDamageDone()
        {
            // Code omitted:
            //
            // Does an expensive calculation and returns
            // the result of that calculation.
            for (int i = 0; i < 10; i++)
            {
                Thread.Sleep(7);
            }

            return "done with large calculation";
        }
    }
}
