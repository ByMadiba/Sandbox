﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using FluentAssertions;
using Xunit;
using Xunit.Abstractions;

namespace ZamaLokhuNalokhu.ZamiAsynchronousProgramming
{
    public class TaskBasedAsyncProgram
    {
        private readonly ITestOutputHelper _testOutputHelper;

        public TaskBasedAsyncProgram(ITestOutputHelper testOutputHelper)
        {
            _testOutputHelper = testOutputHelper;
        }

        // https://docs.microsoft.com/en-us/dotnet/standard/parallel-programming/task-based-asynchronous-programming

        // https://docs.microsoft.com/en-us/dotnet/api/system.threading.tasks.task-1?view=net-6.0

        [Fact]
        public void TestDetachedChildTasks()
        {
            var sut = DetachedChildTasks();
            sut.Any().Should().BeTrue();

            sut.First().Should().Contain("Outer task",
                "The outer task will complete first");
            sut.Last().Should().Contain("Detached",
                "Detached (child) task was spun off and made to wait. So will complete after the Outer (parent) task");
        }

        static IEnumerable<string> DetachedChildTasks()
        {
            var lines = new List<string>();

            var outer = Task.Factory.StartNew(() =>
            {
                lines.Add("Outer task beginning.");

                var child = Task.Factory.StartNew(() =>
                {
                    Thread.SpinWait(5000);
                    lines.Add("Detached task completed.");
                });
            });

            outer.Wait();
            lines.Add("Outer task completed.");

            return lines;
        }
    }
}
