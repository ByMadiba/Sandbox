﻿using System.Linq;
using System.Text.RegularExpressions;
using FluentAssertions;
using Xunit;
using Xunit.Abstractions;

namespace ZamaLokhuNalokhu.ZamiRegex
{
    public class RegexOperations
    {
        private readonly ITestOutputHelper _testOutputHelper;

        public RegexOperations(ITestOutputHelper testOutputHelper)
        {
            _testOutputHelper = testOutputHelper;
        }

        [Fact]
        public void TestSplitString()
        {
            Regex regex = new Regex("-");         // Split on hyphens.
            string[] substrings = regex.Split("plum--pear");
            foreach (string match in substrings)
            {
                _testOutputHelper.WriteLine("'{0}'", match);
            }

            substrings.Any().Should().BeTrue("Regex split should work");
        }

        [Fact]
        public void TestRegexMatch_WithSubstringMatch()
        {
            var nameToFind = "SendSettlementInstructionsIntraday";

            var names = new[] { "SendSettlementInstructions", "SendSettlementInstructionsIntraday", "arbitrary" };

            var matches = names.Where(_ => Regex.Match(_, nameToFind).Success);

            matches.Any().Should().BeTrue("match");

            var name = names.FirstOrDefault(_ => Regex.Match(_, nameToFind).Success);
            name.Should().NotBe("SendSettlementInstructions", "need to match the whole not just the first few characters");
            name.Should().Be("SendSettlementInstructionsIntraday", "need to match the whole not just the first few characters");
        }
    }
}
