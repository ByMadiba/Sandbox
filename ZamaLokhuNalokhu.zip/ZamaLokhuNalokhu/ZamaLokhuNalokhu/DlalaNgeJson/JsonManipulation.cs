﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using FluentAssertions;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Xunit;
using Xunit.Abstractions;

namespace ZamaLokhuNalokhu.DlalaNgeJson
{
    /// <summary>
    /// Based on our automation testing
    /// </summary>
    public class JsonManipulation
    {
        private readonly ITestOutputHelper _testOutputHelper;

        public JsonManipulation(ITestOutputHelper testOutputHelper)
        {
            _testOutputHelper = testOutputHelper;
        }

        [Theory]
        [InlineData("DenodoSample.json")]
        [InlineData("TagWireSample.json")]
        [InlineData("VaultSample.json")]
        public void TestExtractBusinessKeyValue_UsingJsonOperations(string fileName)
        {
            var directory = @"Samples\";
            var propertyName = "BusinessKey";

            var extracted = GetBusinessKeyValue(directory, fileName, propertyName);

            extracted.Should().NotBeNull("There is definitely a BusinessKey field in the mastered file");
            _testOutputHelper.WriteLine("Extracted object is {0}", extracted);
        }

        object GetBusinessKeyValue(string directory, string file, string propertyName)
        {
            var path = Path.Combine(directory, file);

            var json = File.ReadAllText(path);
            var collection = JArray.Parse(json);

            foreach (var record in collection)
            {
                var businessKeyArtifact = record.SelectToken("BusinessKey");
                var key = businessKeyArtifact.SelectToken("BusinessKey");
                var busKeyObject = Convert.ToString(key);
                var kvp = JsonConvert.DeserializeObject<KeyValuePair<string, object>>(busKeyObject);

                return kvp.Value;
            }

            return null;
        }

        /// <summary>
        /// Usually we extract business key using AUtoTest artifacts
        /// Here we are purely using Json.NET
        /// </summary>
        /// <param name="fileName">the json file</param>
        [Theory]
        [InlineData("DenodoSample.json")]
        [InlineData("TagWireSample.json")]
        [InlineData("VaultSample.json")]
        public void TestExtractBusinessKey_UsingJsonOperations(string fileName)
        {
            var directory = @"Samples\";
            var propertyName = "BusinessKey";

            var extracted = ExtractBusinessKey(directory, fileName, propertyName);

            extracted.Should().NotBeNullOrEmpty("There is definitely a BusinessKey field in the mastered file");
            extracted.Name.Should().NotBeNullOrEmpty("There is definitely a BusinessKey field in the mastered file");
            extracted.Name.Should().Be(propertyName, "That's the property we set out to extract");
        }

        JProperty ExtractBusinessKey(string directory, string file, string propertyName)
        {
            var path = Path.Combine(directory, file);

            var json = File.ReadAllText(path);
            var collection = JArray.Parse(json);

            foreach (var record in collection)
            {
                var jObject = JObject.FromObject(record);
                var jProperty = jObject.Property(propertyName);

                if (jProperty != null)
                {
                    var businessKeyContainerObject = JObject.FromObject(jProperty.Value);
                    var businessKey = businessKeyContainerObject.Property(propertyName);

                    return businessKey;
                }
            }

            return null;
        }
    }
}
