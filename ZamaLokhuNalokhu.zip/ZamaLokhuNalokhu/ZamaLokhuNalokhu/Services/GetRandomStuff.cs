﻿using System;
using System.IO;

namespace ZamaLokhuNalokhu.Services
{
    class GetRandomStuff
    {
        internal DateTime GetRandomDate(int randomizer)
        {
            return DateTime.Today.AddDays(randomizer);
        }

        internal string GetRandomString(int randomizer)
        {
            var words = File.ReadAllLines(@"Samples\Sample.txt");
            var totalSentences = words.Length;
            var sentence = string.Empty;

            randomizer = EnsureNumericIsPositive(randomizer);
            randomizer = randomizer > totalSentences ? totalSentences / 4 : randomizer;

            for (int index = randomizer; index < totalSentences; index++)
            {
                sentence += words[index];
            }

            return sentence.Length > 100 ? sentence.Substring(0, 100) : sentence;
        }

        internal long GetRandomNumber(int randomizer)
        {
            var random = new Random();
            return random.Next(randomizer, int.MaxValue);
        }
        
        private int EnsureNumericIsPositive(int randomizer)
        {
            if (randomizer > 0)
                return randomizer;

            return randomizer * -1;
        }
    }
}
