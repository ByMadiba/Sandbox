﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentAssertions;
using Xunit;
using Xunit.Abstractions;

namespace ZamaLokhuNalokhu
{
    public class ZamiParallelInvoke
    {
        private readonly ITestOutputHelper _testOutputHelper;

        public ZamiParallelInvoke(ITestOutputHelper testOutputHelper)
        {
            _testOutputHelper = testOutputHelper;
        }

        [Fact]
        public void TestParallelInvoke()
        {
            // Retrieve Tehuti's "Halls of Amenti" from FILE.
            string[] words = CreateWordArray(@"Samples\Sample.txt");
            var longestWord = string.Empty;
            var mostCommonWord = string.Empty;
            var wordCount = 0;
            
            // Perform three tasks in parallel on the source array
            Parallel.Invoke(() =>
                {
                    _testOutputHelper.WriteLine("Begin first task...");
                    longestWord = GetLongestWord(words);
                },  // close first Action

                () =>
                {
                    _testOutputHelper.WriteLine("Begin second task...");
                    mostCommonWord = GetMostCommonWords(words);
                }, //close second Action

                () =>
                {
                    _testOutputHelper.WriteLine("Begin third task...");
                    wordCount = GetCountForWord(words, "Amenti");
                } //close third Action
            ); //close parallel.invoke

            _testOutputHelper.WriteLine("Returned from Parallel.Invoke");
            longestWord.Should().NotBeNullOrEmpty();
            mostCommonWord.Should().NotBeNullOrEmpty();
            wordCount.Should().BeGreaterThan(7);
        }

        private int GetCountForWord(string[] words, string term)
        {
            var findWord = from word in words
                           where word.ToUpper().Contains(term.ToUpper())
                           select word;

            _testOutputHelper.WriteLine($@"Task 3 -- The word ""{term}"" occurs {findWord.Count()} times.");

            return findWord.Count();
        }

        private static string GetMostCommonWords(string[] words)
        {
            var frequencyOrder = from word in words
                                 where word.Length > 6
                                 group word by word into g
                                 orderby g.Count() descending
                                 select g.Key;

            var commonWords = frequencyOrder.Take(10);

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Task 2 -- The most common words are:");
            foreach (var v in commonWords)
            {
                sb.AppendLine("  " + v);
            }

            return sb.ToString();
        }

        private string GetLongestWord(string[] words)
        {
            var longestWord = (from w in words
                               orderby w.Length descending
                               select w).First();

            _testOutputHelper.WriteLine($"Task 1 -- The longest word is {longestWord}.");
            return longestWord;
        }

        // An http request performed synchronously for simplicity.
        string[] CreateWordArray(string path)
        {
            _testOutputHelper.WriteLine($"Retrieving from {path}");

            var lines = File.ReadAllLines(path);

            string s = string.Empty;
            Array.ForEach(lines, _ => s += $" {_}");

            // Separate string into an array of words, removing some common punctuation.
            return s.Split(
                new char[] { ' ', '\u000A', ',', '.', ';', ':', '-', '_', '/' },
                StringSplitOptions.RemoveEmptyEntries);
        }
    }
}
