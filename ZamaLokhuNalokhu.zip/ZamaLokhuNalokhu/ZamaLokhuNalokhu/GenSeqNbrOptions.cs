﻿using System;
using System.Collections.Generic;
using System.Text;
using FluentAssertions;
using Xunit;
using Xunit.Abstractions;

namespace ZamaLokhuNalokhu
{
    public class GenSeqNbrOptions
    {
        private readonly ITestOutputHelper _testOutputHelper;

        public GenSeqNbrOptions(ITestOutputHelper testOutputHelper)
        {
            _testOutputHelper = testOutputHelper;
        }

        /// <summary>
        /// Option 1: Use Date Time Stamp
        /// </summary>
        /// <param name="sodDateTime">the SOD date</param>
        /// <param name="eoDateTime">the EOD date</param>
        [Theory]
        [MemberData(nameof(GetDateData), parameters: 30)]
        public void TestOptionOne_DateTimeStamp(DateTime sodDateTime, DateTime eoDateTime)
        {
            _testOutputHelper.WriteLine("SOD: {0} | EOD {1}", sodDateTime, eoDateTime);

            var difference = this.DateTimeStampToLong_LimitToTenN(sodDateTime, eoDateTime);
            _testOutputHelper.WriteLine("Afternoon - Morning = {0}", difference);

            difference.Should().BePositive("08h00 is before 15h30");
        }

        public static IEnumerable<object[]> GetDateData(int noOfTests)
        {
            var allData = new List<object[]>();

            // Hours & Minutes
            for (var i = 0; i < noOfTests; i++)
            {
                var r = new Random();
                var randomYear = r.Next(2022, 2033);
                var randomMonth = r.Next(1, 13);
                var randomDay = r.Next(1, 30);
                var randomHour = r.Next(0, 13); // SOD usually before midday
                var randomMinute = r.Next(0, 60);
                var randomSecond = r.Next(0, 60);
                var randomMilliseconds = r.Next(111, 123456);
                var addMilliseconds = TimeSpan.FromMilliseconds(randomMilliseconds);

                var currentSod = new DateTime(randomYear, randomMonth, randomDay, randomHour, randomMinute, randomSecond);

                allData.Add(new object[]
                {
                    currentSod.Add(addMilliseconds),
                    currentSod.AddHours(8)
                });
            }

            return allData;
        }

        long DateTimeStampToLong_LimitToTenN(DateTime morning, DateTime afternoon)
        {
            var morningFormattedString = morning.ToString(@"yyMMddHHmmssffffff");
            var afternoonFormattedString = afternoon.ToString(@"yyMMddHHmmssffffff");

            _testOutputHelper.WriteLine("Morning date time as string {0}", morningFormattedString);
            _testOutputHelper.WriteLine("Afternoon date string as string {0}", afternoonFormattedString);

            var morningSubstring = morningFormattedString.Substring(0, 10);
            var afternoonSubstring = afternoonFormattedString.Substring(0, 10);

            var morningNumeric = Convert.ToInt64(morningSubstring);
            var afternoonNumeric = Convert.ToInt64(afternoonSubstring);

            _testOutputHelper.WriteLine("Morning time {0} is 10n numeric value {1}", morning, morningNumeric);
            _testOutputHelper.WriteLine("Afternoon time {0} is 10n numeric value {1}", afternoon, afternoonNumeric);

            var difference = afternoonNumeric - morningNumeric;
            return difference;
        }

        public string GetGenSeqNo()
        {
            var currentDate = DateTime.Now.ToString(@"yyMMddHHmmssffffff");
            return currentDate.Substring(0, 10);
        }

        [Theory]
        [MemberData(nameof(GetIntegerData), parameters: 30)]
        public void TestOptionTwo_AppendTextToSequenceNumber(long sequenceNumber)
        {
            var sequenceNumberText = sequenceNumber.ToString();
            var initialLength = sequenceNumberText.Length;

            var convertedSequenceNumber = this.ConvertNumberToStringWithLengthTenN(sequenceNumber);
            convertedSequenceNumber.Length.Should().Be(10, "that's the requirement");

            if (initialLength < 10)
                convertedSequenceNumber.Should().EndWith("1",
                    "0000000000 is the addendum we append to the initial sequence number");
        }

        string ConvertNumberToStringWithLengthTenN(long sequenceNumber)
        {
            var addendum = "1111111111";
            var sequenceNumberText = sequenceNumber.ToString();
            var appended = string.Concat(sequenceNumberText, addendum);
            var result = appended.Substring(0, 10);

            _testOutputHelper.WriteLine("Sequence Number: {0} => Converted Text: {1} => Return Field: {2}", sequenceNumber, appended, result);

            return result;
        }

        //long ConvertNumberToTenN(long sequenceNumber)
        //{
        //    string sequenceNumberText = this.ConvertNumberToStringWithLengthTenN(sequenceNumber);

        //    var senderRefLength = sequenceNumberText.Length;

        //    if (senderRefLength > 10)
        //    {
        //        var formattedNumeric = sequenceNumberText.Substring(0, 10);
        //        return Convert.ToInt64(formattedNumeric);
        //    }

        //    if (senderRefLength < 10)
        //    {

        //        var missing = (int)10 - senderRefLength;
        //        var maxPossible = Int64.MaxValue;
        //        var max = maxPossible.ToString().Substring(0, missing);
        //        var formattedNumeric = string.Concat(senderRefAsText, max);
        //        return Convert.ToInt64(formattedNumeric);

        //    }
        //    return Convert.ToInt64(sequenceNumberText);
        //}

        public static IEnumerable<object[]> GetIntegerData(int noOfTests)
        {
            var allData = new List<object[]>();
            var random = new Random();

            allData.Add(new object[] { 0 });
            allData.Add(new object[] { random.Next(0, 99999) }); // have some smaller values available

            // Hours & Minutes
            for (var i = 0; i < noOfTests; i++)
            {
                allData.Add(new object[] { RandomLongGenerator() });
                allData.Add(new object[] { random.Next(0, int.MaxValue) });
            }

            allData.Add(new object[] { random.Next(0, 99999) });
            allData.Add(new object[] { long.MaxValue });

            return allData;
        }

        static long RandomLongGenerator()
        {
            Random random = new Random();
            byte[] bytes = new byte[8];
            random.NextBytes(bytes);
            var randomLong = BitConverter.ToInt64(bytes, 0);

            if (randomLong < 0)
                randomLong *= -1; // make it positive

            return randomLong;
        }
    }
}
