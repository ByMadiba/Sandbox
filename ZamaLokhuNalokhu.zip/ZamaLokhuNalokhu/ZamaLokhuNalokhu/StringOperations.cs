using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace ZamaLokhuNalokhu
{
    using System;
    using FluentAssertions;
    using Xunit;
    using Xunit.Abstractions;

    public class StringOperations
    {
        private readonly ITestOutputHelper _testOutputHelper;

        public StringOperations(ITestOutputHelper testOutputHelper)
        {
            _testOutputHelper = testOutputHelper;
        }


        [Fact]
        public void TestIndexOfWithIndexOf()
        {
            var isoBytes = File.ReadAllBytes(@"Samples\ISO15022_MT910.txt");

            var message = System.Text.Encoding.Default.GetString(isoBytes);

            if (!string.IsNullOrEmpty(message))
            {
                var startIndex = message.IndexOf(":20:") + 4;
                var currentIndicator = message.Substring(startIndex, 15);
                _testOutputHelper.WriteLine("currentIndicator = {0}", currentIndicator);

                _testOutputHelper.WriteLine($"Funding message received. Expected JSECleat but received {currentIndicator}");
            }

            message.Should().NotBeNullOrEmpty("must read message");
        }

        [Fact]
        public void TestGetTextWithinTwoIndexOf()
        {
            var allFiles = Directory.GetFiles(@"Samples\", "*MT910*");

            foreach (var mt910File in allFiles)
            {
                var isoBytes = File.ReadAllBytes(mt910File);

                var message = System.Text.Encoding.Default.GetString(isoBytes);

                if (!string.IsNullOrEmpty(message))
                {
                    var indexOfAmountField = message.IndexOf("ZAR") + 3;
                    var initialExtractedValue = message.Substring(indexOfAmountField);
                    //_testOutputHelper.WriteLine("initialExtractedValue (everything after ZAR) = {0}", initialExtractedValue);

                    var indexOfAmountEnd = initialExtractedValue.IndexOf(Environment.NewLine);
                    var extractedText = initialExtractedValue.Substring(0, indexOfAmountEnd);
                    _testOutputHelper.WriteLine(
                        "SecondaryExtractedValue (initialExtractedValue til carriage field) = {0}", extractedText);
                }

                message.Should().NotBeNullOrEmpty("must read message");
            }
        }

        [Fact]
        public void TestSplitPascalCaseToSentence()
        {
            string[] tests = {
                "AutomaticTrackingSystem",
                "XMLEditor",
                "AnXMLAndXSLT2.0Tool",
                "EligibleSecuritiesRequestTagWire",
                "SetYieldReqTagWire",
                "MitTradeEmBizAudit",
                "SettlementInstructionChildrenVault",
                "ConfirmDebitSwiftAudit",
                "ValuateReqBizAudit"
            };

            foreach (var test in tests)
            {
                var businessName = ChangeCamelCaseToSeparateWords(test);
                _testOutputHelper.WriteLine("businessName:{0}", businessName);
                businessName.Should().Contain(" ", "camel case changed to separate words");
            }
        }

        string ChangeCamelCaseToSeparateWords(string camelCaseText)
        {

            Regex r = new Regex(
                @"(?<=[A-Z])(?=[A-Z][a-z])|(?<=[^A-Z])(?=[A-Z])|(?<=[A-Za-z])(?=[^A-Za-z])"
            );

            var businessName = r.Replace(camelCaseText, " ");

            return businessName;
        }

        [Theory]
        [InlineData("ValuateReqBizAudit")]
        public void TestChangeTechnicalNamesToBusinessName(string technicalName)
        {
            var businessName = ChangeCamelCaseToSeparateWords(technicalName);

            var techToBusinessCypher = new Dictionary<string, string>
            {
                { "Req", "Request" },
                { "Rsp", "Response" },
                { "Msg", string.Empty }
            };

            foreach (var (oldKey, newKey) in techToBusinessCypher)
            {
                businessName = businessName.Replace(oldKey, newKey);
            }

            _testOutputHelper.WriteLine("{0}", businessName);
            businessName.Should().Contain("Request", "original Req been replaced with business readable value");
            businessName.Should().NotContain("Rsp", "must replace with business readable value");
            businessName.Should().NotContain("Msg", "must replace with business readable value");
        }

        [Theory]
        [InlineData("MessageReferenceOne")]
        public void TestStringFormat_WithISO15022Message(string changeTo)
        {
            var isoLines = File.ReadAllLines(@"Samples\ISO15022Message.txt");

            foreach (var iso in isoLines)
            {
                if (iso.StartsWith(":72:"))
                {
                    _testOutputHelper.WriteLine("Line before formatting {0}", iso);
                    iso.Should().NotContain(changeTo, "this is before I format");
                    var formatted = string.Format(iso, changeTo);
                    _testOutputHelper.WriteLine("Line after formatting {0}", formatted);
                    formatted.Should().Contain(changeTo, "this is after I format");
                }
            }
        }


        [Fact]
        public void TestString_ArrayForeachConcat()
        {
            var arrayOfStrings = new string[] { "one", "two", "three"};

            var finalText = string.Empty;
            _testOutputHelper.WriteLine("Before: {0}", finalText);

            Array.ForEach(arrayOfStrings, _ => finalText += _);

            _testOutputHelper.WriteLine("After: {0}", finalText);

            finalText.Should().NotBeNullOrEmpty("appended to");

            var midText = " in between ";
            var currentLength = finalText.Length;

            Array.ForEach(arrayOfStrings, _ => finalText += string.Concat(midText, _));

            _testOutputHelper.WriteLine("With mid text: {0}", finalText);

            finalText.Length.Should().BeGreaterThan(currentLength, "we've appended");
            finalText.Should().Contain(midText, "we concat'ed");
        }

        [Fact]
        [SuppressMessage("ReSharper", "StringLiteralTypo")]
        public void Test_ReadFileCountHowManyTimesEachSubtitle()
        {
            // PTYB/STRA/SITMANZA
            var isoLines = File.ReadAllLines(@"Samples\ISO15022_MT569.txt");
            var subHeadings = new Dictionary<string, string>
            {
                { "16R:GENL", "16R Start of Block GENL" }
                , {"16R:COLLPRTY", "16R Start of Block COLLPRTY. Optional Repetitive Subsequence A1 Collateral Parties"}
                , {"16S:COLLPRTY", "16S End of Block COLLPRTY. End of Subsequence A1 Collateral Parties"}
                , {"16R:LINK", "16R Start of Block LINK. Optional Repetitive Subsequence A2 Linkages"}
                , {"16S:LINK", "16S End of Block LINK. End of Subsequence A2 Linkages"}
                , {"16S:GENL", "16S End of Block GENL. End of Sequence A General Information"}
                , {"16R:SUMM", "16R Start of Block SUMM. Mandatory Sequence B Overall Summary"}
                , {"16S:SUMM", "16S End of Block SUMM. End of Sequence B Overall Summary"}
                , {"16R:SUME", "16R Start of Block SUME. Mandatory Repetitive Sequence C Summary by Exposure Type"}
                , {"16R:SUMC", "16R Start of Block SUMC. Optional Repetitive Subsequence C1 Summary by Counterparty"}
                , {"16R:TRANSDET", "16R Start of Block TRANSDET. Mandatory Repetitive Subsequence C1a Transaction Details"}
                , {"16R:VALDET", "16R Start of Block VALDET. Optional Repetitive Subsequence C1a1 Valuation Details"}
                , {"16R:SECDET", "16R Start of Block SECDET. Optional Repetitive Subsequence C1a1A Securities Details"}
                , {"16S:SECDET", "16S End of Block SECDET. End of Subsequence C1a1A Securities Details"}
                , {"16S:VALDET", "16S End of Block VALDET.  End of Subsequence C1a1 Valuation Details"}
                , {"16S:TRANSDET", "16S End of Block TRANSDET. End of Subsequence C1a Transaction Details"}
                , {"16S:SUMC", "16S End of Block SUMC. End of Subsequence C1 Summary by Counterparty"}
                , {"16S:SUME", "16S End of Block SUME. End of Sequence C Summary by Exposure Type"}
                , {"16R:ADDINFO", "16R Start of Block ADDINFO. Optional Repetitive Sequence D Additional Information"}
                , {"16S:ADDINFO", "16S End of Block ADDINFO. End of Sequence D Additional Information"}
                , {"35B:ISIN", "the isin"}
            };

            var reached = this.GetOccurencePerSearchItem(subHeadings, isoLines);

            reached.Count.Should().BeGreaterThan(0, "at least :16R:GENL is repetitive");

            foreach (var reach in reached)
            {
                _testOutputHelper.WriteLine("Heading:{0} | Total: {1}", reach.Key, reach.Value);
            }
            //_testOutputHelper.WriteLine(" : {0}");
            //_testOutputHelper.WriteLine(" : {0}");
            //_testOutputHelper.WriteLine(" : {0}");
            //_testOutputHelper.WriteLine(" : {0}");
            //_testOutputHelper.WriteLine(" : {0}");
        }

        [Fact]
        [SuppressMessage("ReSharper", "StringLiteralTypo")]
        public void Test_ReadFileCountHowManyTimesEachHeading()
        {
            // PTYB/STRA/SITMANZA
            var isoLines = File.ReadAllLines(@"Samples\ISO15022_MT569.txt");
            var subHeadings = new Dictionary<string, string>
            {
                { "16R:GENL", "16R Start of Block GENL" }
                , {"16R:COLLPRTY", "16R Start of Block COLLPRTY. Optional Repetitive Subsequence A1 Collateral Parties"}
                , {"16S:COLLPRTY", "16S End of Block COLLPRTY. End of Subsequence A1 Collateral Parties"}
                , {"16R:LINK", "16R Start of Block LINK. Optional Repetitive Subsequence A2 Linkages"}
                , {"16S:LINK", "16S End of Block LINK. End of Subsequence A2 Linkages"}
                , {"16S:GENL", "16S End of Block GENL. End of Sequence A General Information"}
                , {"16R:SUMM", "16R Start of Block SUMM. Mandatory Sequence B Overall Summary"}
                , {"16S:SUMM", "16S End of Block SUMM. End of Sequence B Overall Summary"}
                , {"16R:SUME", "16R Start of Block SUME. Mandatory Repetitive Sequence C Summary by Exposure Type"}
                , {"16R:SUMC", "16R Start of Block SUMC. Optional Repetitive Subsequence C1 Summary by Counterparty"}
                , {"16R:TRANSDET", "16R Start of Block TRANSDET. Mandatory Repetitive Subsequence C1a Transaction Details"}
                , {"16R:VALDET", "16R Start of Block VALDET. Optional Repetitive Subsequence C1a1 Valuation Details"}
                , {"16R:SECDET", "16R Start of Block SECDET. Optional Repetitive Subsequence C1a1A Securities Details"}
                , {"16S:SECDET", "16S End of Block SECDET. End of Subsequence C1a1A Securities Details"}
                , {"16S:VALDET", "16S End of Block VALDET.  End of Subsequence C1a1 Valuation Details"}
                , {"16S:TRANSDET", "16S End of Block TRANSDET. End of Subsequence C1a Transaction Details"}
                , {"16S:SUMC", "16S End of Block SUMC. End of Subsequence C1 Summary by Counterparty"}
                , {"16S:SUME", "16S End of Block SUME. End of Sequence C Summary by Exposure Type"}
                , {"16R:ADDINFO", "16R Start of Block ADDINFO. Optional Repetitive Sequence D Additional Information"}
                , {"16S:ADDINFO", "16S End of Block ADDINFO. End of Sequence D Additional Information"}
//                , { @":95L|P|Q|R::[A-Z0-9]{4}\/[A-Z0-9]{4}\/([A-Z0-9]+)", @"MT569: (31) Field 95a: Party. 95a 4!c Party (see qualifier description)L, P, Q, or R
//Option L	:4!c//18!c2!n	(Qualifier)(Legal Entity Identifier)
//Option P	:4!c//4!a2!a2!c[3!c]	(Qualifier)(Identifier Code)
//Option Q	:4!c//4*35x	(Qualifier)(Name and Address)
//Option R	:4!c/8c/34x	(Qualifier)(Data Source Scheme)(Proprietary Code)"}
                //, { @":95L|P|Q|R::[A-Z0-9]{4}\/[A-Z0-9]{4}\/([A-Z0-9]+)", @"MT569: (31) Field 95a: Party. 95a 4!c Party | Option R	:4!c/8c/34x	(Qualifier)(Data Source Scheme)(Proprietary Code)"}
                , { @":95[L|P|Q|R]{1}::PTY[A-Z]{1}\/[A-Z0-9]{4}\/([A-Z0-9]+)", @"(PTYB) MT569: (31) Field 95a: Party. 95a 4!c Party | Option R	:4!c/8c/34x	(Qualifier)(Data Source Scheme)(Proprietary Code)"}
            };

            var reached = this.GetOccurencePerSearchItem(subHeadings, isoLines);

            reached.Count.Should().BeGreaterThan(0, "at least :16R:GENL is repetitive");

            foreach (var reach in reached)
            {
                _testOutputHelper.WriteLine("Heading:{0} | Total: {1}", reach.Key, reach.Value);
            }
            //_testOutputHelper.WriteLine(" : {0}");
            //_testOutputHelper.WriteLine(" : {0}");
            //_testOutputHelper.WriteLine(" : {0}");
            //_testOutputHelper.WriteLine(" : {0}");
            //_testOutputHelper.WriteLine(" : {0}");
        }

        Dictionary<string, long> GetOccurencePerSearchItem(Dictionary<string, string> subHeadings, IEnumerable<string> isoLines)
        {
            var reached = new Dictionary<string, long>();
            var counter = 0;

            foreach (var isoLine in isoLines)
            {
                counter++;
                // _testOutputHelper.WriteLine("[{0}] isoLine : {1}", counter, isoLine);
                foreach (var subHeadingInfo in subHeadings)
                {
                    var subHeading = subHeadingInfo.Key;

                    if (Regex.IsMatch(isoLine, subHeading))
                    {
                        long currentTotal = 1;

                        if (reached.ContainsKey(subHeading))
                        
                        {
                            var previousTotal = reached[subHeading];
                            reached[subHeading] = currentTotal = previousTotal + currentTotal;
                        }
                        else
                        {
                            reached.Add(subHeading, 1);
                        }
                        //_testOutputHelper.WriteLine("[Tot:{0}|#:{1}] {2} => {3}", currentTotal, counter, subHeading, subHeadingInfo.Value);
                        _testOutputHelper.WriteLine("line:{0} {1} => {2}", counter, isoLine, subHeading);
                    }
                }
            }

            return reached;
        }

        [Fact]
        public void Test_ReadFileFigurePattern()
        {
            var isoLines = File.ReadAllLines(@"Samples\ISO15022_MT569.txt");
            var linesProcessed = new Dictionary<long, string>();
            var tagsProcessed = new Dictionary<string, string>();
            var lineNo = 0;

            foreach (var isoLine in isoLines)
            {
                lineNo++;
                var matched = Regex.Match(isoLine, @":([0-9]{2}[A-Z]{1}):");

                if (!matched.Success)
                    continue;

                var swiftTag = matched.Groups[1].Value;
                linesProcessed.Add(lineNo, swiftTag);
                _testOutputHelper.WriteLine("{0}:{1}", lineNo, swiftTag);

                //if (tagsProcessed.ContainsKey(swiftTag))

                //{
                //    var previousTotal = tagsProcessed[swiftTag];
                //    tagsProcessed[swiftTag] = currentTotal = previousTotal + currentTotal;
                //}
                //else
                //{
                //    tagsProcessed.Add(swiftTag, 1);
                //}
            }

            linesProcessed.Count.Should().BeGreaterThan(0, "message has swift tags");

            //foreach (var reach in processed)
            //{
            //    _testOutputHelper.WriteLine("Heading:{0} | Total: {1}", reach.Key, reach.Value);
            //}
            //_testOutputHelper.WriteLine(" : {0}");
            //_testOutputHelper.WriteLine(" : {0}");
            //_testOutputHelper.WriteLine(" : {0}");
            //_testOutputHelper.WriteLine(" : {0}");
            //_testOutputHelper.WriteLine(" : {0}");
        }

        [Theory]
        [InlineData(1, "FROM[\\t\\s]*\\[[A-Z]{3}_([A-Za-z]+)\\]", "db name for BizTalk (BTS_x) Audit")]
        [InlineData(2, "[\\[]*dbo[\\]]*\\.[\\[]*([A-Za-z]+)[\\]]*", "db name for Derivatives Audit")]
        [InlineData(3, "WHERE(.+)=.+", "WHERE clause")]
        [InlineData(4, "WHERE.+=(.+)", "WHERE condition")]
        [InlineData(5, "AND(.+)=.+", "AND clause")]
        [InlineData(6, "AND.+=(.+)", "AND condition")]
        //[InlineData(2, "", "")]
        public void Test_ExtractIdentifiersFromQuery_Patterns(int index, string pattern, string extractionType)
        {
            var sqlSelect = @"
SELECT	*
FROM	[BTS_DerivativesAudit].[dbo].[MessageHistory]
WHERE	CONVERT(DATE, ModifiedDate) = '2022/07/05 00:00:00'
AND     MessageType = 'LUTL(CSD3)'
FOR JSON AUTO;
";
            _testOutputHelper.WriteLine("sqlSelect:{0}", sqlSelect);

            _testOutputHelper.WriteLine("ExtractionType:{0}", extractionType);

            if (index == 1)
            {
                var matched = Regex.Match(sqlSelect, @"FROM[\t\s]*\[[A-Z]{3}_([A-Za-z]+)\]");
                matched.Success.Should().BeTrue($"index has a winning (basic for now) pattern for {extractionType}");

                var extracted = matched.Groups[1].Value;
                _testOutputHelper.WriteLine("Extracted:{0}", extracted);
                return;
            }

            if (index == 2)
            {
                var matches = Regex.Matches(sqlSelect, @"[\[]*dbo[\]]*\.[\[]*([A-Za-z]+)[\]]*");

                foreach (Match matched in matches)
                {
                    matched.Success.Should().BeTrue($"index has a winning (basic for now) pattern for {extractionType}");

                    var extracted = matched.Groups[1].Value;
                    _testOutputHelper.WriteLine("Extracted:{0}", extracted);
                }

                return;
            }

            if (index == 3)
            {
                var matched = Regex.Match(sqlSelect, @"WHERE(.+)=.+");
                matched.Success.Should().BeTrue($"index has a winning (basic for now) pattern for {extractionType}");

                var extracted = matched.Groups[1].Value;
                _testOutputHelper.WriteLine("Extracted:{0}", extracted);
                return;
            }

            if (index == 4)
            {
                var matched = Regex.Match(sqlSelect, @"WHERE.+=(.+)");
                matched.Success.Should().BeTrue($"index has a winning (basic for now) pattern for {extractionType}");

                var extracted = matched.Groups[1].Value;
                _testOutputHelper.WriteLine("Extracted:{0}", extracted);
                return;
            }
            
            if (index == 5)
            {
                var matched = Regex.Match(sqlSelect, @"AND(.+)=.+");
                matched.Success.Should().BeTrue($"index has a winning (basic for now) pattern for {extractionType}");

                var extracted = matched.Groups[1].Value;
                _testOutputHelper.WriteLine("Extracted:{0}", extracted);
                return;
            }

            if (index == 6)
            {
                var matched = Regex.Match(sqlSelect, @"AND.+=(.+)");
                matched.Success.Should().BeTrue($"index has a winning (basic for now) pattern for {extractionType}");

                var extracted = matched.Groups[1].Value;
                _testOutputHelper.WriteLine("Extracted:{0}", extracted);
                return;
            }
        }

        [Fact]
        public void Test_ExtractIdentifiersFromQuery()
        {
            var sqlSelect = @"
SELECT	*
FROM	[BTS_DerivativesAudit].[dbo].[MessageHistory]
WHERE	CONVERT(DATE, ModifiedDate) = '2022/07/05 00:00:00'
AND     MessageType = 'LUTL(CSD3)'
FOR JSON AUTO;
";
            _testOutputHelper.WriteLine("sqlSelect:{0}", sqlSelect);

            var sut = ExtractIdentifiersFromQuery(sqlSelect, "this gets all users who have re-submitted");
            sut.Should().NotBeNullOrEmpty("extract ID");

            var name = string.Empty;

            foreach (var extracted in sut)
            {
                _testOutputHelper.WriteLine("extracted:{0}", extracted);

                var updatedName = name + extracted;
                name = updatedName;
            }

            _testOutputHelper.WriteLine("Final Name: {0}", name);
            name.Should().NotBeNullOrEmpty("populated by sut");
        }

        [Theory]
        [InlineData("BTS_DerivativesAudit", "SELECT\t* FROM\t[BTS_DerivativesAudit].[dbo].[MessageHistory] WHERE\tCONVERT(DATE, ModifiedDate) = '2022/07/05 00:00:00' AND     MessageType = 'LUTL(CSD3)' FOR JSON AUTO;")]
        [InlineData("BTS_SWIFTAudit", "SELECT\t[mID],[mReference],[mCode],[mSubCode],[mContent],[mDirection],[IsValid],[ValidationDetails],[DateTimeCreated], AssetClass\r\nFROM\t[BTS_SWIFTAudit].[dbo].[SWIFTAudit] (NOLOCK)\r\nWHERE\tCONVERT(DATE, DateTimeCreated) = '2022/10/05 00:00:00'\r\nAND \tmCode = '527'\r\nAND \tmSubCode = ''\r\nAND\t\tmDirection = 'I'\r\nORDER BY DateTimeCreated\r\nFOR JSON AUTO;")]
        [InlineData("ClearingAudit", "SELECT  *\r\nFROM    [ClearingAudit] (NOLOCK)\r\nWHERE   CONVERT(DATE, DateTimeCreated) = '2022/10/05 00:00:00'\r\nAND\t    mCode = 'CLR0010'\r\nORDER BY DateTimeCreated")]
        [InlineData("CIS", "SELECT\t[SequenceNumber]\r\n               ,[MessageType]\r\n               ,[ProcessDateTime]\r\n        \t   ,[Message] =\t\r\n        \t\t   CASE\r\n        \t\t\t\tWHEN LEN(CAST([Message] AS VARCHAR(MAX))) - 20 > 0\r\n        \t\t\t\tTHEN RIGHT(CAST([Message] AS VARCHAR(MAX)), LEN(CAST([Message] AS VARCHAR(MAX))) - 20)\r\n        \t\t\t\tELSE CAST([Message] AS VARCHAR(MAX))\r\n        \t\t\tEND\r\n        FROM    [MSG_RawMessageAuditLog_CollateralManagement] (NOLOCK)\r\n        WHERE   CONVERT(DATE, MessageDate) = '2022/10/05 00:00:00'\r\n        AND     MessageType = 'GetEligibleSecuritiesWithPricesRspMsg'\r\n        ORDER BY ProcessDateTime\r\n        FOR JSON AUTO;\r\r\n")]
        //[InlineData("", "")]
        public void Test_ExtractIdentifier(string description, string sqlSelect)
        {
            var sut = ExtractIdentifier(sqlSelect, description);
            _testOutputHelper.WriteLine("extracted:{0}", sut);
            sut.Should().NotBeNullOrEmpty("IdentityExtracted");
        }

        string ExtractIdentifier(string sqlSelect, string description)
        {
            var identifiers = ExtractIdentifiersFromQuery(sqlSelect, description);
            
            var name = string.Empty;
            foreach (var identifier in identifiers)
            {
                var updatedName = name + identifier;
                name = updatedName;
            }

            return name;
        }

        IEnumerable<string> ExtractIdentifiersFromQuery(string sqlSelect, string description)
        {
            var identifiers = new Dictionary<string, string>();

            //var dbMatch = Regex.Match(sqlSelect, @"FROM[\t\s]*\[[A-Z]{3}_([A-Za-z]+)\]");
            //var viewOrTable = Regex.Match(sqlSelect, @"[\[]*dbo[\]]*\.[\[]*([A-Za-z]+)[\]]*");
            //var whereClause = Regex.Match(sqlSelect, @"WHERE(.+)=.+");
            //var whereCondition = Regex.Match(sqlSelect, @"WHERE.+=(.+)");
            //var andClause = Regex.Match(sqlSelect, @"AND(.+)=.+");
            //var andCondition = Regex.Match(sqlSelect, @"AND.+=(.+)");

            var matches = new Match[]
            {
                Regex.Match(sqlSelect, @"FROM[\t\s]*\[[A-Z]{3}_([A-Za-z]+)\]"),
                Regex.Match(sqlSelect, @"[\[]*dbo[\]]*\.[\[]*([A-Za-z]+)[\]]*"),
                Regex.Match(sqlSelect, @"WHERE(.+)=.+"),
                Regex.Match(sqlSelect, @"WHERE.+=(.+)"),
                Regex.Match(sqlSelect, @"AND(.+)=.+"),
                Regex.Match(sqlSelect, @"AND.+=(.+)"),
            };

            foreach (var matched in matches)
            {
                var identifier = GetMatchedValue(matched);

                if (string.IsNullOrEmpty(identifier))
                    continue;

                if (identifiers.ContainsKey(identifier))
                    continue;

                identifiers.Add(identifier, identifier);
            }


            return identifiers.Keys.ToArray();
        }

        string GetMatchedValue(Match matched)
        {
            var matchedValue = string.Empty;

            if (matched.Success)
            {
                var rawText = matched.Groups[1].Value;
                matchedValue = SanitizeText(rawText);
            }

            return matchedValue;
        }

        string SanitizeText(string rawText)
        {
            var sanitized = rawText.Replace("FOR JSON AUTO", string.Empty);
            sanitized = sanitized.Replace("AND", string.Empty);
            sanitized = sanitized.Replace("Audit", string.Empty);
            sanitized = sanitized.Replace("MessageType", "Message");
            sanitized = sanitized.Replace("MessageCode", "Message");
            sanitized = sanitized.Replace("CONVERT(DATE,", string.Empty);
            sanitized = sanitized.Replace(" 00:00:00", string.Empty);

            sanitized = sanitized.Replace("'", string.Empty);
            sanitized = sanitized.Replace("-", string.Empty);
            sanitized = sanitized.Replace("=", string.Empty);
            sanitized = sanitized.Replace(";", string.Empty);
            sanitized = sanitized.Replace("(", string.Empty);
            sanitized = sanitized.Replace(")", string.Empty);
            sanitized = sanitized.Replace("[", string.Empty);
            sanitized = sanitized.Replace("]", string.Empty);
            sanitized = sanitized.Replace("/", string.Empty);
            sanitized = sanitized.Replace("\\", string.Empty);

            sanitized = Regex.Replace(sanitized, @"\s+", string.Empty);
            
            return sanitized;
        }
    }
}