using System;
using FluentAssertions;
using Xunit;

namespace ZamaLokhuNalokhu
{
    public class ZamiFunc
    {
        [Fact]
        public void TestSimpleFunc()
        {
            var sut = UseTheFunction(FunctionToPassAsParameter);

            sut.Should().BeGreaterOrEqualTo(10, "passed in Func param that adds 10");
        }

        static int FunctionToPassAsParameter(int x)
        {
            return x + 10;
        }

        static int UseTheFunction(Func<int, int> functionToPass)
        {
            int i = functionToPass(22);
            return i;
        }

        [Fact]
        public void TestFuncGetPositiveValue()
        {
            var isPositive = CallTheFunctionPassedAsParameter(10, BoolFunctionToPassAsParameter);
            isPositive.Should().BeTrue("passed a positive value");
        }

        [Fact]
        public void TestFuncGetNegativeValue()
        {
            var isPositive = CallTheFunctionPassedAsParameter(-100, BoolFunctionToPassAsParameter);
            isPositive.Should().BeFalse("passed a negative value");
        }

        static bool BoolFunctionToPassAsParameter(int x)
        {
            var i =  x + 10;
            return i > 0;
        }

        static bool CallTheFunctionPassedAsParameter(int myParam, Func<int, bool> functionToPass)
        {
            var isPositive = functionToPass(myParam);
            return isPositive;
        }
    }
}
