﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using FluentAssertions;
using Xunit;
using Xunit.Abstractions;

namespace ZamaLokhuNalokhu
{
    public class CultureInfoStuff
    {
        private readonly ITestOutputHelper _testOutputHelper;

        public CultureInfoStuff(ITestOutputHelper testOutputHelper)
        {
            _testOutputHelper = testOutputHelper;
        }

        /// <summary>
        /// AllCultures	7
        /// All cultures that recognized by.NET, including neutral and specific cultures and custom cultures created by the user.
        /// On.NET Framework 4 and later versions and .NET Core running on Windows, it includes the culture data available from the Windows operating system.
        /// On.NET Core running on Linux and macOS, it includes culture data defined in the ICU libraries.
        /// AllCultures is a composite field that includes the NeutralCultures, SpecificCultures, and InstalledWin32Cultures values.
        ///
        /// NeutralCultures	1
        /// Cultures that are associated with a language but are not specific to a country/region.
        /// </summary>
        [Fact]
        public void TestCultureInfo_AllCultures()
        {
            CultureInfo[] cultureInfos =
                CultureInfo.GetCultures(CultureTypes.AllCultures & ~CultureTypes.NeutralCultures);

            foreach (var cultureInfo in cultureInfos)
            {
                _testOutputHelper.WriteLine("culture info: {0}", cultureInfo);
                var displayName = cultureInfo.DisplayName;
                var isoCode = cultureInfo.ThreeLetterISOLanguageName;
                _testOutputHelper.WriteLine("Display Name: {0} | Language code {1}", displayName, cultureInfo.Name);
                _testOutputHelper.WriteLine("ISO code: {0} | NativeName: {1}", isoCode, cultureInfo.NativeName);

                if (displayName.Contains("("))
                {
                    var country = displayName.Substring(displayName.IndexOf("(", StringComparison.Ordinal));
                    country = country.Replace("(", string.Empty).Replace(")", string.Empty);
                    _testOutputHelper.WriteLine("Country: {0}", country);
                }
            }

            true.Should().BeTrue("Sithule, sibhekile");
        }
        
        [Fact]
        public void TestCultureInfo()
        {
            var cultureInfos = CultureInfo.GetCultures(CultureTypes.AllCultures);

            foreach (var cultureInfo in cultureInfos)
            {
                _testOutputHelper.WriteLine("culture info: {0}", cultureInfo);
                var displayName = cultureInfo.DisplayName;
                var isoCode = cultureInfo.ThreeLetterISOLanguageName;
                _testOutputHelper.WriteLine("Display Name: {0} | Language code {1}", displayName, cultureInfo.Name);
                _testOutputHelper.WriteLine("ISO code: {0} | NativeName: {1}", isoCode, cultureInfo.NativeName);

                if (displayName.Contains("("))
                {
                    var country = displayName.Substring(displayName.IndexOf("(", StringComparison.Ordinal));
                    country = country.Replace("(", string.Empty).Replace(")", string.Empty);
                    _testOutputHelper.WriteLine("Country: {0}", country);
                }
            }

            true.Should().BeTrue("Sithule, sibhekile");
        }

        [Fact]
        public void TestDateToString_WithAfricanCurrentCultures()
        {
            var theDate = DateTime.Now;
            var stringedDate = theDate.ToString("D");

            var cultureInfos = CultureInfo.GetCultures(CultureTypes.AllCultures);

            foreach (var cultureInfo in cultureInfos)
            {
                var displayName = cultureInfo.DisplayName;

                if (!displayName.Contains("(")) continue;

                var languageAndCounty = displayName.Split("(");
                if (languageAndCounty.Length > 2) continue;

                var language = languageAndCounty[0];
                var country = languageAndCounty[1].Replace(")", string.Empty);
                var culturedDate = theDate.ToString("D", cultureInfo);
                _testOutputHelper.WriteLine("Country: {0} | Language: {1} | Date: {2}", country, language, culturedDate);
                DateTime.TryParse(stringedDate, out _).Should().BeTrue("Must ToString to a valid format");
            }
            
            true.Should().BeTrue("Sithule, sibhekile");
        }
    }
}
