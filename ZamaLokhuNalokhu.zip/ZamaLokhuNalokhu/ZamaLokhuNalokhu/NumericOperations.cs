﻿using System;
using System.Globalization;
using System.Reflection.PortableExecutable;
using FluentAssertions;
using Xunit;
using Xunit.Abstractions;

namespace ZamaLokhuNalokhu
{
    public class NumericOperations
    {
        private readonly ITestOutputHelper _testOutputHelper;

        public NumericOperations(ITestOutputHelper testOutputHelper)
        {
            _testOutputHelper = testOutputHelper;
        }

        [Fact]
        public void TestConvertCurrencyStringToDecimal()
        {
            var inputs = new[] { "101001,45", "30333,3" };
            foreach (var input in inputs)
            {
                var currency = decimal.Parse(input, NumberStyles.AllowCurrencySymbol | NumberStyles.Number);
                _testOutputHelper.WriteLine("String: {0} Decimal: {1}", input, currency);
            }
        }

        [Fact]
        public void TestRandom_WithRange()
        {
            //for integers
            var r = new Random();
            var rInt = r.Next(0, 100);

            rInt.Should().BeLessThan(100,
                "Returns a positive random integer within the specified minimum and maximum range (includes min and excludes max)");

            //for doubles
            var range = 100;
            var rDouble = r.NextDouble() * range;

            rDouble.Should().BeLessThan(100,
                "Returns a positive random integer within the specified minimum and maximum range (includes min and excludes max)");
        }

        [Fact]
        public void TestLongVsDouble()
        {
            var myLong = long.MaxValue;
            var myDouble = double.MaxValue; // 99999999999999.9 - 9223372036854775807; // double.MaxValue - long.MaxValue // avoiding overflow

            _testOutputHelper.WriteLine("Long: {0} | Double: {1}", myLong, myDouble);

            var convertLongToDouble = Convert.ToDouble(myLong);
            var convertDoubleToLong = (long) (myDouble);

            _testOutputHelper.WriteLine("Converted: Long {0} => Double {1}", myLong, convertLongToDouble);
            _testOutputHelper.WriteLine("Converted: Double {0} => Long {1}", myDouble, convertDoubleToLong);

            false.Should().BeTrue("am not sure what's happening here. Need more reading");
            convertDoubleToLong.Should().BeLessOrEqualTo(myLong, "tshintsha daai ding");
            convertLongToDouble.Should().BeGreaterOrEqualTo(myDouble, "chencha daai ding");
        }

        [Fact]
        public void TestRandomLongGenerator()
        {
            var r = new Random();

            for (int i = 0; i < 10; i++)
            {
                var generatedLong = this.RandomLongGenerator(r);
                _testOutputHelper.WriteLine("Randomly Generated Number: {0}", generatedLong);
                generatedLong.Should().NotBe(0, "method generates Integer /  Int64 / long values");
                generatedLong.Should().BeLessOrEqualTo(long.MaxValue);
            }
        }

        long RandomLongGenerator(Random random)
        {
            byte[] bytes = new byte[8];
            random.NextBytes(bytes);
            return BitConverter.ToInt64(bytes, 0);
        }

        [Fact]
        public void TestRandomLongGenerator_WithPositiveValuesOnly()
        {
            var r = new Random();

            for (int i = 0; i < 10; i++)
            {
                var generatedLong = this.RandomLongGenerator_PositiveValuesOnly(r);
                _testOutputHelper.WriteLine("Randomly Generated Number: {0}", generatedLong);
                generatedLong.Should().BePositive("method generates Positive Integer /  Int64 / long values");
            }
        }

        long RandomLongGenerator_PositiveValuesOnly(Random random)
        {
            byte[] bytes = new byte[8];
            random.NextBytes(bytes);
            var randomLong = BitConverter.ToInt64(bytes, 0);

            if (randomLong < 0)
                randomLong = randomLong * -1; // make it positive

            return randomLong;
        }

        [Fact]
        public void Test_ConvertToPositive()
        {
            var randomInt = 5;
            var sut = this.ConvertToPositive(randomInt);
            sut.Should().BeGreaterThan(0, "must be a positive number");
            _testOutputHelper.WriteLine("Before {0} | After {1}", randomInt, sut);

            randomInt = -5;
            sut = this.ConvertToPositive(randomInt);
            sut.Should().BeGreaterThan(0, "must be a positive number");
            _testOutputHelper.WriteLine("Before {0} | After {1}", randomInt, sut);
        }

        int ConvertToPositive(int randomizer)
        {
            if (randomizer > 0)
                return randomizer;

            return randomizer * -1;
        }

    }
}
