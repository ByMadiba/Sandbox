﻿using System.Collections;
using System.Collections.Generic;
using ZamaLokhuNalokhu.Services;

namespace ZamaLokhuNalokhu.ZamiXUnit
{
    class ZamiClassData : IEnumerable<object[]>
    {
        public IEnumerator<object[]> GetEnumerator()
        {
            var randomizer = new GetRandomStuff();
            yield return new object[] { 12, randomizer.GetRandomDate(12), randomizer.GetRandomString(12), randomizer.GetRandomNumber(12) };

            for (int index = 1; index <= 5; index++)
            {
                yield return new object[] { index, randomizer.GetRandomDate(index), randomizer.GetRandomString(index), randomizer.GetRandomNumber(index) };
            }

            yield return new object[] { -5, randomizer.GetRandomDate(-5), randomizer.GetRandomString(-5), randomizer.GetRandomNumber(-5) };
        }

        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
    }
}