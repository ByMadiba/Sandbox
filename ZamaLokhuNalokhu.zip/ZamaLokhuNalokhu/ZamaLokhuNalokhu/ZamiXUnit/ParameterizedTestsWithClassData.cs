﻿using System;
using System.Collections.Generic;
using System.Text;
using FluentAssertions;
using Xunit;
using Xunit.Abstractions;
using ZamaLokhuNalokhu.Services;

namespace ZamaLokhuNalokhu.ZamiXUnit
{
    public class ParameterizedTestsWithClassData
    {
        private readonly ITestOutputHelper _testOutputHelper;
        static GetRandomStuff _randomizer = new GetRandomStuff();

        public ParameterizedTestsWithClassData(ITestOutputHelper testOutputHelper)
        {
            _testOutputHelper = testOutputHelper;
        }

        [Theory]
        [ClassData(typeof(ZamiClassData))]
        public void TestParameterizedTest_WithClassData(long index, DateTime aDate, string someText, long aNumber)
        {
            _testOutputHelper.WriteLine("Number:{0} | Date:{1} | Text:{2} | Numeric: {3}", index, aDate, someText, aNumber);

            aDate.Should().NotBe(DateTime.MinValue, "parameter required! Can't be null");
            someText.Should().NotBeNullOrEmpty("parameter required! Can't be null");
            aNumber.Should().NotBe(int.MinValue, "parameter required! Can't be null");
        }

        [Theory, MemberData(nameof(ZamiMemberData))]
        public void TestParameterizedTest_WithMemberData(long index, DateTime aDate, string someText, long aNumber)
        {
            _testOutputHelper.WriteLine("Number:{0} | Date:{1} | Text:{2} | Numeric: {3}", index, aDate, someText, aNumber);

            aDate.Should().NotBe(DateTime.MinValue, "parameter required! Can't be null");
            someText.Should().NotBeNullOrEmpty("parameter required! Can't be null");
            aNumber.Should().NotBe(int.MinValue, "parameter required! Can't be null");
        }
        
        public static IEnumerable<object[]> ZamiMemberData =>
            new List<object[]>
            {
                new object[] { -2, _randomizer.GetRandomDate(-2), _randomizer.GetRandomString(-2), _randomizer.GetRandomNumber(-2) },
                new object[] { 12, _randomizer.GetRandomDate(12), _randomizer.GetRandomString(12), _randomizer.GetRandomNumber(12) },
                new object[] { 1, _randomizer.GetRandomDate(1), _randomizer.GetRandomString(1), _randomizer.GetRandomNumber(1) },
                new object[] { 2, _randomizer.GetRandomDate(2), _randomizer.GetRandomString(2), _randomizer.GetRandomNumber(2) },
            };
    }
}
