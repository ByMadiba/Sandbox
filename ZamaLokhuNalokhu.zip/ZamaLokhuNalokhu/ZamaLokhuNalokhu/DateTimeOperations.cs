﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using FluentAssertions;
using Xunit;
using Xunit.Abstractions;

namespace ZamaLokhuNalokhu
{
    public class DateTimeOperations
    {
        private readonly ITestOutputHelper _testOutputHelper;

        public DateTimeOperations(ITestOutputHelper testOutputHelper)
        {
            _testOutputHelper = testOutputHelper;
        }

        [Fact]
        public void TestDatesForEquality()
        {
            var newYearsDay = new DateTime(2022, 01, 01);
            var januaryFirst = new DateTime(2022, 01, 01);

            var sut = DateTime.Equals(newYearsDay, januaryFirst);

            sut.Should().BeTrue("January 1st is so called New Years Day");
        }

        [Fact]
        public void TestDatesEqual_WithEquals()
        {
            var todayIs = DateTime.Now;

            var todaysYear = todayIs.Year;
            var todaysMonth = todayIs.Month;
            var todaysDay = todayIs.Day;

            var todayIsAnotherDay = new DateTime(todaysYear, todaysMonth, todaysDay);

            var sut = DateTime.Equals(todayIs, todayIsAnotherDay);
            sut.Should().BeFalse("it is false as the Equals method checks the time too");

            sut = DateTime.Equals(todayIs.Date, todayIsAnotherDay.Date);
            sut.Should().BeTrue("Today is today and today is another day");
        }

        [Fact]
        public void TestDatesEqual_WithCompareTo()
        {
            var todayIs = DateTime.Now;

            var todaysYear = todayIs.Year;
            var todaysMonth = todayIs.Month;
            var todaysDay = todayIs.Day;

            var todayIsAnotherDay = new DateTime(todaysYear, todaysMonth, todaysDay);

            var sut = todayIs.CompareTo(todayIsAnotherDay);
            sut.Should().BeGreaterThan(0, "Greater than zero = This instance (todayIs) is later than value (todayIsAnotherDay).");

            sut = todayIsAnotherDay.CompareTo(todayIs);
            sut.Should().BeLessThan(0, "Less than zero = This instance (todayIsAnotherDay) is earlier than value(todayIs).");

            todayIsAnotherDay = new DateTime(todayIs.Ticks);
            sut = todayIsAnotherDay.CompareTo(todayIs);
            sut.Should().Be(0, "Zero	= This instance (todayIsAnotherDay) is the same as value.(todayIs).");
        }

        [Fact]
        public void TestDatesEqual_WithOperators()
        {
            var todayIs = DateTime.Now;

            var todaysYear = todayIs.Year;
            var todaysMonth = todayIs.Month;
            var todaysDay = todayIs.Day;

            var todayIsAnotherDay = new DateTime(todaysYear, todaysMonth, todaysDay);

            var sut = todayIs > todayIsAnotherDay;
            sut.Should().BeTrue("Because of time, todayIs (DateTime.Now) is greater than todayIsAnotherDay (defaulted to 12h00)");

            sut = todayIs.Date > todayIsAnotherDay.Date;
            sut.Should().BeFalse("Only checking the Date: todayIs (DateTime.Now) is the same as todayIsAnotherDay (defaulted to 12h00)");

            sut = todayIs.Date == todayIsAnotherDay.Date;
            sut.Should().BeTrue("Only checking the Date: todayIs (DateTime.Now) is the same as todayIsAnotherDay (defaulted to 12h00)");
        }

        [Fact]
        public void TestDateToString_WithO_RoundTripPattern()
        {
            var theDate = DateTime.Now;
            var stringedDate = theDate.ToString("O");
            _testOutputHelper.WriteLine("Normal format: {0} | O round trip format: {1}", theDate, stringedDate);
            DateTime.TryParse(stringedDate, out _).Should().BeTrue("Must ToString to a valid format");
        }

        [Fact]
        public void TestDateToString_WithD_LongDateFormat()
        {
            var theDate = DateTime.Now;
            var stringedDate = theDate.ToString("D");
            _testOutputHelper.WriteLine("Normal format: {0} | D round trip format: {1}", theDate, stringedDate);
            _testOutputHelper.WriteLine("Using culture es-MX: {0}", theDate.ToString("D", CultureInfo.CreateSpecificCulture("es-MX")));
            _testOutputHelper.WriteLine("Using culture zu-ZA: {0}", theDate.ToString("D", CultureInfo.CreateSpecificCulture("zu-ZA")));
            DateTime.TryParse(stringedDate, out _).Should().BeTrue("Must ToString to a valid format");
        }



        [Fact]
        public void TestDateTimeStampToStringToLong_MustLimitToTenCharacters_TestMorningIsLessThanAfternoon()
        {
            var addMilliseconds = TimeSpan.FromMilliseconds(123);
            var morning = new DateTime(2012, 12, 21, 8, 0, 1);
            var afternoon = new DateTime(2012, 12, 21, 15, 35, 36);
            morning = morning.Add(addMilliseconds);
            afternoon = afternoon.Add(addMilliseconds);

            _testOutputHelper.WriteLine("Morning date time is {0}", morning);
            _testOutputHelper.WriteLine("Afternoon date time is {0}", afternoon);

            var morningFormattedString = morning.ToString(@"yyMMddHHmmssffffff");
            var afternoonFormattedString = afternoon.ToString(@"yyMMddHHmmssffffff");

            _testOutputHelper.WriteLine("Morning date time as string {0}", morningFormattedString);
            _testOutputHelper.WriteLine("Afternoon date string as string {0}", afternoonFormattedString);

            var morningSubstring = morningFormattedString.Substring(0, 10);
            var afternoonSubstring = afternoonFormattedString.Substring(0, 10);

            morningSubstring.Length.Should().Be(10, "thats what's specified");
            afternoonSubstring.Length.Should().Be(10, "thats what's specified");

            var morningNumeric = Convert.ToInt64(morningSubstring);
            var afternoonNumeric = Convert.ToInt64(afternoonSubstring);

            _testOutputHelper.WriteLine("Morning time {0} is numeric value {1}", morning, morningNumeric);
            _testOutputHelper.WriteLine("Afternoon time {0} is numeric value {1}", afternoon, afternoonNumeric);

            morningNumeric.Should().BeLessThan(afternoonNumeric, "08h00 is earlier than 15h00");

            var difference = afternoonNumeric - morningNumeric;
            _testOutputHelper.WriteLine("Afternoon - Morning = {0}", difference);

            difference.Should().BePositive("08h00 is before 15h30");
        }

        long DateTimeStampToLong_LimitToTenN(DateTime morning, DateTime afternoon)
        {
            var morningFormattedString = morning.ToString(@"yyMMddHHmmssffffff");
            var afternoonFormattedString = afternoon.ToString(@"yyMMddHHmmssffffff");

            _testOutputHelper.WriteLine("Morning date time as string {0}", morningFormattedString);
            _testOutputHelper.WriteLine("Afternoon date string as string {0}", afternoonFormattedString);

            var morningSubstring = morningFormattedString.Substring(0, 10);
            var afternoonSubstring = afternoonFormattedString.Substring(0, 10);

            var morningNumeric = Convert.ToInt64(morningSubstring);
            var afternoonNumeric = Convert.ToInt64(afternoonSubstring);

            _testOutputHelper.WriteLine("Morning time {0} is 10n numeric value {1}", morning, morningNumeric);
            _testOutputHelper.WriteLine("Afternoon time {0} is 10n numeric value {1}", afternoon, afternoonNumeric);
            
            var difference = afternoonNumeric - morningNumeric;
            return difference;
        }
        
        [Theory]
        [MemberData(nameof(GetData), parameters: 30)]
        public void TestDateTimeStampToLong_LimitToTenN(DateTime sodDateTime, DateTime eoDateTime)
        {
            _testOutputHelper.WriteLine("SOD: {0} | EOD {1}", sodDateTime, eoDateTime);

            var difference = this.DateTimeStampToLong_LimitToTenN(sodDateTime, eoDateTime);
            _testOutputHelper.WriteLine("Afternoon - Morning = {0}", difference);

            difference.Should().BePositive("08h00 is before 15h30");
        }

        public static IEnumerable<object[]> GetData(int noOfTests)
        {
            var allData = new List<object[]>();

            // Hours & Minutes
            for (var i = 0; i < noOfTests; i++)
            {
                var r = new Random();
                var randomYear = r.Next(2022, 2033);
                var randomMonth = r.Next(1, 13);
                var randomDay = r.Next(1, 30);
                var randomHour = r.Next(0, 13); // SOD usually before midday
                var randomMinute = r.Next(0, 60);
                var randomSecond = r.Next(0, 60);
                var randomMilliseconds = r.Next(111, 123456);
                var addMilliseconds = TimeSpan.FromMilliseconds(randomMilliseconds);

                var currentSod = new DateTime(randomYear, randomMonth, randomDay, randomHour, randomMinute, randomSecond);

                allData.Add(new object[]
                {
                    currentSod.Add(addMilliseconds),
                    currentSod.AddHours(8)
                });
            }

            return allData;
        }

        [Fact]
        public void TestGetDate_ExposureFileReferenceGenerator()
        {
            var sequences = new Dictionary<string, string>();
            for (int j = 0; j < 50; j++)
            {
                for (int i = 0; i < 60; i++)
                {
                    var test = GetDate(i);
                    //var output = Convert.ToInt64(test);
                    //sequences.Add(output, test);
                    sequences.Add(test, test);
                    _testOutputHelper.WriteLine("{0}", test);
                }
            }

            sequences.Should().NotBeNullOrEmpty("Dictionary.Add will fail if generated sequence number is not unique");

            foreach (var sequence in sequences)
            {
                sequence.Value.Length.Should().Be(16, "18 length string");
            }
        }

        [Theory]
        [MemberData(nameof(GetData), parameters: 90)]
        public void TestGetDate_ExposureFileReferenceGenerator_WithRandomDates(DateTime sodDateTime, DateTime eoDateTime)
        {
            var sequences = new Dictionary<string, string>();
            for (int j = 0; j < 5; j++)
            {
                for (int i = 0; i < 6; i++)
                {
                    var test = GetDate(sodDateTime);
                    //var output = Convert.ToInt64(test);
                    //sequences.Add(output, test);
                    sequences.Add(test, test);
                    _testOutputHelper.WriteLine("{0}", test);
                }
            }

            sequences.Should().NotBeNullOrEmpty("Dictionary.Add will fail if generated sequence number is not unique");

            foreach (var sequence in sequences)
            {
                sequence.Value.Length.Should().Be(16, "16 length string");
            }
        }

        public string GetDate(int batchNumber)
        {

            string date = DateTime.Now.ToString("MMddHHmmssffffff");
            //var r = new Random();
            //var rInt = r.Next(10, 100);

            return date;

            //string date = DateTime.Now.ToString("yyyyMMddHHmmss");
            //var r = new Random();
            //var rInt = r.Next(10, 100);
            //date = date + rInt.ToString("D2");

            //return date;

            //var theTime = DateTime.Now;
            //string fTime = theTime.ToString("HHmmss");
            //var r = new Random();
            //var rInt = r.Next(1000, 10000);
            //string mSeconds = theTime.ToString("ffffff");

            //var reference = string.Concat(fTime, rInt, mSeconds);


            //return reference;

            //string date = DateTime.Now.ToString("MMddHHmmssffffff");
            //var reference = Convert.ToInt64(date);

            ////string date = DateTime.Now.ToString("HHmmssffffff");
            //date = string.Concat(date, batchNumber.ToString("D2"));

            ////string date = DateTime.Now.ToString("HHmmssffffff");
            ////var r = new Random();
            ////date = date + batchNumber.ToString("D4");

            //return date;

            //var date = DateTime.Now;
            //var dated = date.ToString("HHmmssffffff");

            //var r = new Random();
            //var rInt = r.Next(1000, 10000);

            //dated = dated + rInt;

            //return dated;
            /*
            var date = DateTime.Now;
            //_testOutputHelper.WriteLine("{0}", date);
            var dated = date.ToString("HHmmssffffff");
            //_testOutputHelper.WriteLine("{0}", dated);

            //string date = DateTime.Now.ToString("MMddHHmmssfff");
            //var theDate = new DateTime(2022, 11, 11, 13, 30, 33);

            var r = new Random();
            var rInt = r.Next(1000, 10000);
            //_testOutputHelper.WriteLine("{0} (date) {1} (Random)", date, rInt);

            dated = dated + rInt; //.ToString("D2");
            //_testOutputHelper.WriteLine("{0} = date + Random", dated);

            //var threadId = System.Threading.Thread.CurrentThread.ManagedThreadId;
            //date = date + threadId.ToString("D4");
            //_testOutputHelper.WriteLine("date + threadId = {0}", date);

            //date = date + batchNumber.ToString("D2");
            //_testOutputHelper.WriteLine("date after D = {0}", date);
            //return date.Length > 16 ? date.Substring(0, 16) : date;

            return dated;
            */
        }

        public string GetDate(DateTime theDate)
        {
            //string date = DateTime.Now.ToString("MMddHHmmssfff");

            //return date;

            var r = new Random();
            var rInt = r.Next(0, 9);
            string date = GetDate(rInt);
            return date;


            //string date = theDate.ToString("HHmmssffffff");
            //var r = new Random();
            //var rInt = r.Next(1000, 10000);
            //date = date + rInt;
            //return date;

            //var date = DateTime.Now;
            //_testOutputHelper.WriteLine("{0}", date.ToString("yyyy-MM-dd HH:mm:ss.ffffff"));
            //var dated = date.ToString("HHmmssffffff");

            //var r = new Random();
            //var rInt = r.Next(1000, 10000);

            //dated = dated + rInt;

            //return dated;
            /*
            var date = DateTime.Now;
            //_testOutputHelper.WriteLine("{0}", date);
            var dated = date.ToString("HHmmssffffff");
            //_testOutputHelper.WriteLine("{0}", dated);

            //string date = DateTime.Now.ToString("MMddHHmmssfff");
            //var theDate = new DateTime(2022, 11, 11, 13, 30, 33);

            var r = new Random();
            var rInt = r.Next(1000, 10000);
            //_testOutputHelper.WriteLine("{0} (date) {1} (Random)", date, rInt);

            dated = dated + rInt; //.ToString("D2");
            //_testOutputHelper.WriteLine("{0} = date + Random", dated);

            //var threadId = System.Threading.Thread.CurrentThread.ManagedThreadId;
            //date = date + threadId.ToString("D4");
            //_testOutputHelper.WriteLine("date + threadId = {0}", date);

            //date = date + batchNumber.ToString("D2");
            //_testOutputHelper.WriteLine("date after D = {0}", date);
            //return date.Length > 16 ? date.Substring(0, 16) : date;

            return dated;
            */
        }

        [Fact]
        public void TestGetTime_ExposureFileReferenceGenerator()
        {
            var sequences = new Dictionary<long, string>();
            for (int j = 0; j < 5; j++)
            {
                for (int i = 0; i < 6; i++)
                {
                    var test = GetTicks(i);
                    var output = Convert.ToInt64(test);
                    sequences.Add(output, test);
                    _testOutputHelper.WriteLine("{0}", output);
                }
            }

            sequences.Should().NotBeNullOrEmpty("Dictionary.Add will fail if generated sequence number is not unique");
        }


        public string GetTicks(int batchNumber)
        {
            var tSpen = DateTime.Now.Ticks;
            _testOutputHelper.WriteLine("{0} = tSpen", tSpen);

            var tSpan = tSpen.ToString();
            
            return tSpan.Length > 16 ? tSpan.Substring(0, 16) : tSpan;
        }

        [Fact]
        public void TestTimeSpanToString_FFF_vs_ff()
        {
            var date = DateTime.Now;
            _testOutputHelper.WriteLine("{0}", date);
            var dated = date.ToString("HHmmssffffff");
            _testOutputHelper.WriteLine("{0}", dated);
            //var sut = TimeSpan.Parse("0:0:6.8954321");
            //_testOutputHelper.WriteLine("Output => fffffff {0}", sut.ToString("fffffff"));
            //_testOutputHelper.WriteLine("Output => FFFFFFF {0}", sut.ToString("FFFFFFF"));
            /*
             * fffffff"	The ten-millionths of a second (or the fractional ticks) in a time interval.

More information: The "fffffff" custom format specifier.	TimeSpan.Parse("0:0:6.8954321"):

fffffff --> 8954321

ss\.fffffff --> 06.8954321
            */
        }
    }
}
