﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using FluentAssertions;
using Xunit;
using Xunit.Abstractions;

namespace ZamaLokhuNalokhu.ZamiIO
{
    public class DirectorySearch
    {
        private readonly ITestOutputHelper _testOutputHelper;

        public DirectorySearch(ITestOutputHelper testOutputHelper)
        {
            _testOutputHelper = testOutputHelper;
        }

        [Fact]
        public void TestDirectoryInfo_GetDatedFolder()
        {
            var logicalDate = new DateTime(2022, 10, 10);
            var businessDate = logicalDate.ToString("yyyy-MM-dd");
            var server = @"VT75DEN8STG01.TB75.TEST.JSE.CO.ZA";
            var directoryPath = $@"Scheduler Exports\BDA Exports\Archive";
            var path = Path.Combine("\\\\", server, directoryPath);
            var dirInfo = new DirectoryInfo(path);


            var isDatedFolder = true;

            if (isDatedFolder)
            {
                var dirInfoList = dirInfo.GetDirectories();
                var dirs = dirInfoList.Where(x => x.Name.Contains(businessDate));

                var sut = dirs.Any();
                sut.Should().BeTrue("there are sub directories");
            }

            if (isDatedFolder)
            {
                var dirInfoList = dirInfo.GetDirectories($"*{businessDate}*").ToList();

                var sut = dirInfoList.Any();
                sut.Should().BeTrue("there are sub directories");
            }
        }

        [Fact]
        public void TestDirectoryInfo_GetDatedFiles()
        {
            var logicalDate = new DateTime(2022, 10, 10);
            var businessDate = logicalDate.ToString("yyyyMMdd");
            var server = @"VT75EIBAT02.TB75.TEST.JSE.CO.ZA";
            var directoryPath = @"ControlMReports";
            var path = Path.Combine("\\\\", server, directoryPath);
            var dirInfo = new DirectoryInfo(path);


            var isDatedFolder = false;
            var isDatedFile = true;

            if (isDatedFolder)
            {
                var dirInfoList = dirInfo.GetDirectories();
                var dirs = dirInfoList.Where(x => x.Name.Contains(businessDate));

                var sut = dirs.Any();
                sut.Should().BeTrue("there are sub directories");

                dirInfo = dirs.First();
            }

            if (isDatedFile)
            {
                var fileInfoList = dirInfo.GetFiles($"*{businessDate}*").ToList();

                var sut = fileInfoList.Any();
                sut.Should().BeTrue("there are sub directories");
            }
        }

        [Fact]
        public void TestDirectorySearch()
        {
            var businessDate = new DateTime(2022,10,10);
            var server = @"VT75DEN8STG01.TB75.TEST.JSE.CO.ZA";
            var directoryPath = @"Scheduler Exports\BDA Exports\Archive";
            var subDirectory = businessDate.ToString("yyyy-MM-dd");
            var path = Path.Combine("\\\\", server, directoryPath, subDirectory);

            var searchPattern = @"BBAP*";

            var dirInfo = new DirectoryInfo(path);
            var files = dirInfo.GetFiles().Where(x => x.LastWriteTime.Date == businessDate).ToList();

            files.Any().Should().BeTrue($"there are files matching the pattern {searchPattern} expected at location {path}");
        }

        [Fact]
        public void TestDirectorySearch_NoNativeRegexSearch()
        {
            var logicalDate = new DateTime(2022, 10, 10);
            var businessDate = logicalDate.ToString("yyyy-MM-dd");

            var server = @"VT75DEN8STG01.TB75.TEST.JSE.CO.ZA";
            var directoryPath = @"Scheduler Exports\BDA Exports\Archive";
            var path = Path.Combine("\\\\", server, directoryPath);

            var dirInfo = new DirectoryInfo(path);
            var foundSubDirectories = false;
            
            var subDirectories = dirInfo.GetDirectories();

            if (subDirectories.Any())
            {
                foreach (var subDirectory in subDirectories)
                {
                    var matched = Regex.Match(subDirectory.Name, @"(\d{4}-\d{2}-\d{2})");

                    if (!matched.Success) continue;

                    var fileDate = matched.Groups[1].Value;

                    if (string.Equals(fileDate, businessDate))
                    {
                        path = Path.Combine(path, fileDate);
                        dirInfo = new DirectoryInfo(path);
                    }
                }

                var filtered = subDirectories.Where(x =>
                    Regex.IsMatch(x.Name, @"(\d{4}-\d{2}-\d{2})")
                    && x.Name.Contains(businessDate)
                );

                var newDirectory = filtered.FirstOrDefault();

                if (newDirectory != null)
                {
                    foundSubDirectories = true;
                }
            }

            foundSubDirectories.Should().BeTrue("There are dated sub directories");
        }
        
        [Fact]
        public void TestDirectorySearch_WithRegex()
        {
            var businessDate = new DateTime(2022, 10, 10);
            var server = @"VT75DEN8STG01.TB75.TEST.JSE.CO.ZA";
            var directoryPath = @"Scheduler Exports\BDA Exports\Archive";
            var path = Path.Combine("\\\\", server, directoryPath);

            var dirInfo = new DirectoryInfo(path);
            var foundSubDirectories = false;

            var subDirectories = dirInfo.GetDirectories();

            if (subDirectories.Any())
            {
                //var subDir = subDirectories.Where(x => x.n)
                foreach (var subDirectory in subDirectories)
                {
                    var date = businessDate.ToString("yyyy-MM-dd");

                    if (Regex.IsMatch(subDirectory.Name, @"(\d{4}-\d{2}-\d{2})"))
                    {
                        if (string.Equals(subDirectory.Name, date))
                        {
                            foundSubDirectories = true;
                        }
                    }
                }
            }

            foundSubDirectories.Should().BeTrue("There are dated sub directories");
        }

        [Fact]
        public void TestDirectorySearch_WithRegexSimplified()
        {
            var logicalDate = new DateTime(2022, 10, 10);
            var businessDate = logicalDate.ToString("yyyy-MM-dd");
            var server = @"VT75DEN8STG01.TB75.TEST.JSE.CO.ZA";
            var directoryPath = @"Scheduler Exports\BDA Exports\Archive";
            var path = Path.Combine("\\\\", server, directoryPath);

            var dirInfo = new DirectoryInfo(path);
            var foundSubDirectories = false;

            var subDirectories = dirInfo.GetDirectories();

            var filtered = subDirectories.Where(x =>
                Regex.IsMatch(x.Name, @"(\d{4}-\d{2}-\d{2})")
                && x.Name.Contains(businessDate)
            );
            var subDirectory = filtered.FirstOrDefault();

            if (subDirectory != null)
                foundSubDirectories = true;

            foundSubDirectories.Should().BeTrue("There are dated sub directories");
        }

        [Fact]
        public void TestDirectorySearch_WithDatedSubDirectory()
        {
            var businessDate = new DateTime(2022, 06, 14);
            var server = @"VT75DEN8STG01.TB75.TEST.JSE.CO.ZA";
            var directoryPath = @"Scheduler Exports\BDA Exports\Archive";
            var subDirectoryPattern = "yyyy-MM-dd";
            var subDirectory = businessDate.ToString(subDirectoryPattern);
            var path = Path.Combine("\\\\", server, directoryPath, subDirectory);

            var searchPattern = @"BBAP*";

            var dirInfo = new DirectoryInfo(path);
            var files = dirInfo.GetFiles().Where(x => x.LastWriteTime.Date == businessDate).ToList();

            files.Any().Should().BeTrue($"files in subdirectory {subDirectory} matching the pattern {searchPattern} expected at location {path}");
        }

        [Fact]
        public void TestListSubDirectories()
        {
            var path = @"C:\Source\JSE\Enterprise Integration\Source\Applications\StreamInsight";
            var dirInfo = new DirectoryInfo(path);
            var subDirectories = dirInfo.GetDirectories();

            var directories = new List<string>();

            foreach (var subDirectory in subDirectories)
            {
                //_testOutputHelper.WriteLine("Current directory: {0}", subDirectory.Name);
                _testOutputHelper.WriteLine("{0}", subDirectory.Name);
                directories.Add(subDirectory.Name);
            }

            directories.Should().NotBeNullOrEmpty("There are sub directories present");
        }

        [Fact]
        public void TestCommandBuilder()
        {
            var path = @"C:\Source\JSE\Enterprise Integration\Source\Applications\StreamInsight";
            var dirInfo = new DirectoryInfo(path);
            var subDirectories = dirInfo.GetDirectories();

            var username = @"JSE\BongekaM.dev";
            var password = @"MP:+\l.*PogC1Na";

            var directories = new List<string>();

            foreach (var subDirectory in subDirectories)
            {
                var serviceName = subDirectory.Name;
                var indexOfAdapter = serviceName.LastIndexOf('.');
                var adapterName = serviceName.Insert(indexOfAdapter, ".Adapter");

                //_testOutputHelper.WriteLine("Adapter: {0}", adapterName);
                //_testOutputHelper.WriteLine("CEP: {0}", serviceName);
                
                _testOutputHelper.WriteLine($"sc.exe config \"{adapterName}\" obj= \"{username}\" password= \"{password}\" ");
                _testOutputHelper.WriteLine($"sc.exe config \"{serviceName}\" obj= \"{username}\" password= \"{password}\" ");
                directories.Add(subDirectory.Name);
            }

            directories.Should().NotBeNullOrEmpty("There are sub directories present");
        }

        [Fact]
        public void Test_GetCurrentBinDirectory()
        {
            var path = System.IO.Path.GetDirectoryName(
                System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase);

            _testOutputHelper.WriteLine("Path:{0}", path);
            path.Should().NotBeNullOrEmpty("bin folder");
        }
    }
}
