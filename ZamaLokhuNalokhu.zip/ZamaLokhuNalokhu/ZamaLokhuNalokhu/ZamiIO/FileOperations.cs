﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using FluentAssertions;
using Xunit;

namespace ZamaLokhuNalokhu.ZamiIO
{
    public class FileWriteOperations
    {
        [Fact]
        public async void TestWriteToFileAsync()
        {
            var path = $@"Samples\WriteAllLines{DateTime.Today:yyyyMMdd}.txt";

            string[] lines =
            {
                "First line", "Second line", "Third line"
            };

            await WriteToFileAsync(path, lines);

            File.Exists(path).Should().BeTrue("wrote to file");
        }

        public async Task WriteToFileAsync(string path, string[] lines)
        {
            await File.WriteAllLinesAsync(path, lines);
        }

        [Fact]
        public void TestWriteToFile()
        {
            var path = $@"Samples\WriteLine{DateTime.Today:yyyyMMdd}.txt";

            string[] lines =
            {
                "First line", "Second line", "Third line"
            };

            WriteToFile(path, lines);

            File.Exists(path).Should().BeTrue("wrote to file");
        }

        [Fact]
        public void TestAppendToFile()
        {
            var path = $@"Samples\WriteLine{DateTime.Today:yyyyMMdd}.txt";

            string[] lines =
            {
                "Fourth line", "Fifth line", "Sixth line"
            };

            var fileInfo = new FileInfo(path);
            var beforeSize = fileInfo.Length;

            AppendToFile(path, lines);

            fileInfo = new FileInfo(path);
            var afterSize = fileInfo.Length;

            afterSize.Should().BeGreaterThan(beforeSize);
        }

        void WriteToFile(string path, string[] lines)
        {
            // Write the string array to a new file named "WriteLines.txt".
            using (StreamWriter outputFile = new StreamWriter(path))
            {
                foreach (string line in lines)
                    outputFile.WriteLine(line);
            }
        }

        void AppendToFile(string path, string[] lines)
        { 
            // Append text to an existing file named "WriteLines.txt".
            using (StreamWriter outputFile = new StreamWriter(path, true))
            {
                foreach (string line in lines)
                    outputFile.WriteLine(line);
            }
        }
    }
}
