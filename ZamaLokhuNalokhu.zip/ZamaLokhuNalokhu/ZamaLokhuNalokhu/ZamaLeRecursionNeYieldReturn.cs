﻿using System;
using System.Collections.Generic;
using System.Linq;
using FluentAssertions;
using Xunit;

namespace ZamaLokhuNalokhu
{
    public class ZamaLeRecursionNeYieldReturn
    {
        [Fact]
        public void TestPower()
        {
            foreach (int i in Power(2, 8))
            {
                i.Should().NotBe(0);
            }
        }
        
        public static IEnumerable<int> Power(int number, int exponent)
        {
            int result = 1;

            for (int i = 0; i < exponent; i++)
            {
                result = result * number;
                yield return result;
            }
        }
        
        [Fact]
        public void TestRecursion()
        {
            var allTimes = new[]
            {
                new TimeSpan(12, 00, 00),
                new TimeSpan(12, 00, 30),
                new TimeSpan(12, 01, 00),
                new TimeSpan(14, 00, 00),
                new TimeSpan(14, 00, 30),
                new TimeSpan(14, 01, 00),
                new TimeSpan(15, 00, 00),
                new TimeSpan(15, 00, 30),
                new TimeSpan(15, 01, 00)
            };

            var batchingStartTime = new List<TimeSpan>();
            var startTimes = GetBatchedTimes(allTimes, batchingStartTime);

            startTimes.Should().NotBeNullOrEmpty("must get start times");
        }

        IEnumerable<TimeSpan> GetBatchedTimes(IEnumerable<TimeSpan> allTheTimes, List<TimeSpan> startTimes)
        {
            var currentStartTime = allTheTimes.First();

            var nextBatch = allTheTimes.Where(x => x > currentStartTime.Add(TimeSpan.FromMinutes(2)));

            startTimes.Add(currentStartTime);

            if (nextBatch.Any())
            {
                var nextTimes = GetBatchedTimes(nextBatch, startTimes);
            }

            return startTimes;
        }

        [Fact]
        public void TestYieldReturn()
        {
            var index = 0;

            foreach (var currentBatch in GetBatchedMessagesWithYieldReturn())
            {
                index++;
                currentBatch.Any().Should().BeTrue();
                foreach (var concreteClass in currentBatch)
                {
                    concreteClass.Message.Should().Contain($"{index}."); // 1.1, 2.2, 3.1 etc
                }
            }
        }

        IEnumerable<IEnumerable<MyConcreteClass>> GetBatchedMessagesWithYieldReturn()
        {
            var concreteList = new List<MyConcreteClass>
            {
                new MyConcreteClass
                {
                    CreatedTime = new TimeSpan(12, 00, 00),
                    Message = "This is message 1.1"
                },
                new MyConcreteClass
                {
                    CreatedTime = new TimeSpan(12, 01, 00),
                    Message = "This is message 1.2"
                },
                new MyConcreteClass
                {
                    CreatedTime = new TimeSpan(13, 00, 00),
                    Message = "This is message 2.1"
                },
                new MyConcreteClass
                {
                    CreatedTime = new TimeSpan(13, 01, 00),
                    Message = "This is message 2.3"
                },
                new MyConcreteClass
                {
                    CreatedTime = new TimeSpan(13, 01, 30),
                    Message = "This is message 2.3"
                },
                new MyConcreteClass
                {
                    CreatedTime = new TimeSpan(15, 00, 00),
                    Message = "This is message 3.1"
                },
                new MyConcreteClass
                {
                    CreatedTime = new TimeSpan(15, 01, 00),
                    Message = "This is message 3.2"
                }
            };

            var allTheTimes = concreteList.Select(x => x.CreatedTime);

            var batchStartTimes = new List<TimeSpan>();
            var startTimes = GetBatchedTimes(allTheTimes, batchStartTimes);

            foreach (var startTime in startTimes)
            {
                var endTime = startTime.Add(TimeSpan.FromMinutes(2));
                var currentMessages = concreteList.Where(x => x.CreatedTime >= startTime && x.CreatedTime <= endTime);
                yield return currentMessages;
            }
        }
    }

    class MyConcreteClass
    {
        public TimeSpan CreatedTime { get; set; }

        public string Message { get; set; }
    }
}
