﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ZamAmaDesignPattern
{
    public class TestFactoryMethod
    {
    }
}
