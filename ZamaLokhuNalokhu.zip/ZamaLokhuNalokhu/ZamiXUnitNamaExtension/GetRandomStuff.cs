﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace ZamiXUnitNamaExtension
{
    class GetRandomStuff
    {
        internal DateTime GetRandomDate(int randomizer)
        {
            return DateTime.Today.AddDays(randomizer);
        }

        internal string GetRandomString(int randomizer)
        {
            var words = File.ReadAllLines(@"Samples\Sample.txt");
            var totalWords = words.Length;
            var sentence = string.Empty;

            for (int index = 0; index < totalWords; index++)
            {
                sentence += words[index];
            }

            return sentence;
        }
    }
}
